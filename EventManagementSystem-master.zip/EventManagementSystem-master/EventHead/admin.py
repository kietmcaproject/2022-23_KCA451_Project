from django.contrib import admin
from EventHead.models import *
# Register your models here.

admin.site.register(Event_Head)
admin.site.register(Winner)
