from django.contrib import admin
from EventWebSite.models import *

# Register your models here.

admin.site.register(Event)
admin.site.register(news)
admin.site.register(Participants)
admin.site.register(Participation)