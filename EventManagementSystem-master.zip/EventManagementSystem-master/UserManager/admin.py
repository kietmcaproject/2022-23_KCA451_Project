from django.contrib import admin
from UserManager.models import *

# Register your models here.

admin.site.register(Stream)
admin.site.register(College)
admin.site.register(User)
admin.site.register(Event_Committee)
# admin.site.register(Volunteer)
# admin.site.register(Coordinator)
