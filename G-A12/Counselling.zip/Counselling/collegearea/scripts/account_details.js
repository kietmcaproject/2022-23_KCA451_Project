$(document).ready(function(){
$('.pass_change').click(function(){
	 $('.pass_bg, .change_pass').fadeIn(800);
});
$('.close').click(function(){
	$('.pass_bg, .change_pass').fadeOut(800);

});

$('.contact_change').click(function(){
$('.contact_bg , .change_contact').fadeIn(800);
});

$('.close').click(function(){

$('.contact_bg , .change_contact').fadeOut(800);
});

});