<?php
$conn_error='Could not connect.';

$mysql_host = "localhost";
$mysql_db = "ecounselling";
$mysql_user = "root";
$mysql_password = "";


/*$mysql_host='localhost';
$mysql_user='root';
$mysql_password='2014';

$mysql_db='ecounselling';*/

if(!@mysql_connect($mysql_host,$mysql_user,$mysql_password) || !@mysql_select_db($mysql_db)){
	die($conn_error);
}
?>