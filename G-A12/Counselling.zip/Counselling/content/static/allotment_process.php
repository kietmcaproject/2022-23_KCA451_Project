<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Allotment Process</title>
</head>

<body>
<div align="center">
<div  align="justify" style="padding-left:50px;padding-right:25px">
<img src="images/1logoo.jpg"></img><hr>
<div align="center"><h2 style="color:#36F"><u>Allotment Process</u></h2></div><br>
<div style="color:#03C; font:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif; font-size:20px">
1. After Successful Selection of college Preference candidate will have to wait for counselling result.<br><br>
2. College will be allocated based on the selection of college preference according to the candidate rank.<br><br>
3. Allocation will be on vacant seat. Such as candidate get his/her 1st preference college if that college was vacant at that rank, if not then it comes to his/her 2nd preference and so to the 3rd preference.<br><br>
4. If Candidate are not alloted to his/her 1st preference college, then he/she can upgrade to take 2nd counselling. Candidate ma get his/her 1st preference college if that college has atleast a vacant seat.<br><br>
Candidate will get all counselling related information
in <u>http://www.ecounselling.tk/</u>
<br><br>
For any kind of assistance you can
contact us though email mailto: <a href="#">info@ecounselling.tk</a>
<br><br><br><br>
<center><INPUT TYPE='BUTTON' VALUE='Close' onClick='window.close()' style='background-color:#039; color:#FFF; font-size:18px'></center>
<hr>
<div align="center">
Generated @ e-counselling System
<br>
© <a href="http://www.ecounselling.tk/">www.ecounselling.tk</a>
<br><br>
</div>
</div>
</div>
</div>

</body>
</html>
