<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Counselling Process</title>
</head>

<body>
<div align="center">
<div  align="justify" style="padding-left:100px">
<img src="images/1logoo.jpg"></img><hr>
<div align="center">
  <h2 style="color:#36F"><u>Counselling Instruction</u></h2></div>
<p align="center"><h2 align="left">Please read carefully.</h2></p>
<div style="color:#03C; font:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif; font-size:26px">
1. After Successful Candidate registration each candidate
will have an email and password to login into their
candidate area.<br><br>
2. Each candidate will have different college in their preferences,
Candidate can choose 3 different colleges as preferable college.<br><br>
3. Before filling preferences every candidate are requested to go
through previous year statics and closing rank.
<br><br>
4. Once you save your preferences, it is locked for whole
counselling life.<br><br>
5. After Round one counselling each candidate can see his /her
allotment status in candidate area of respective users.<br><br>
6. Those who get their 1st preference college will not get any
other chance to upgrade his/her allotments status but who get
2nd or 3rd preferences college he/she may upgrade for the next
phase round two counselling.<br><br>
7. If he/she did not upgrade, he/she must take admission at the
allotted college other wise he/she will be excluded for the
counselling life.<br><br>
8. Only One time Upgradation is allowable through out the entire Counselling Process. No Upgradation will in 2nd round counselling(If someone choose upgrade).<br><br><br>
For better demo counselling.<br>
Candidate will get all counselling related information
in <u>http://www.ecounselling.tk/</u>
<br><br>
For any kind of assistance you can
contact us though email mailto: <a href="#">info@ecounselling.tk</a>
<br><br><br><br>
<center><INPUT TYPE='BUTTON' VALUE='Close' onClick='window.close()' style='background-color:#039; color:#FFF; font-size:18px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="download_pdf/counselling_process.pdf" target="_blank"><button style='background-color:#039; color:#FFF; font-size:18px'>Download</button></a></center>
<hr>
<div align="center">
Generated @ e-counselling System
<br>
© <a href="http://www.ecounselling.tk/">www.ecounselling.tk</a>
<br><br>
</div>
</div>
</div>
</div>

</body>
</html>
