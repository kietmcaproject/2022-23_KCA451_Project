<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Frequently Asked Questions</title>
</head>

<body>
<div align="center">
<div  align="justify" style="padding-left:50px;padding-right:25px">
<img src="images/1logoo.jpg"></img><hr>
<div align="center"><h2 style="color:#36F"><u>Frequently Asked Questions</u></h2></div><br>
<div style="color:#03C; font:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif; font-size:22px">
Visit properly to get all needed information are on Quick links and Notice Section. You can also watch a demo counselling process video full avialable on demo counselling tab.
<br><br>
For any other query you may write to us at <a href="#">admin@ecounselling.tk</a>
<br><br>
Candidate will get all counselling related information
at <u>http://www.ecounselling.tk/</u>
<br><br>
For any kind of assistance you can
contact us though email mailto: <a href="#">info@ecounselling.tk</a>
<br><br><br><br>
<center><INPUT TYPE='BUTTON' VALUE='Close' onClick='window.close()' style='background-color:#039; color:#FFF; font-size:18px'></center>
<hr>
<div align="center">
Generated @ e-counselling System
<br>
© <a href="http://www.ecounselling.tk/">www.ecounselling.tk</a>
<br><br>
</div>
</div>
</div>
</div>

</body>
</html>
