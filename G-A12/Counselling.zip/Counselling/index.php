<?php
header("location:./content/");
?>