package in.co.online.crime.Bean;

public class RoleBean extends BaseBean{

	private String rolename;

	public String getRolename() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
	
}
