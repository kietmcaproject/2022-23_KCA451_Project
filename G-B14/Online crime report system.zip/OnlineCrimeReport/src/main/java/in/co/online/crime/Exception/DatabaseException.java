package in.co.online.crime.Exception;

public class DatabaseException  extends Exception {
	private DatabaseException(String msg) {
         super (msg);
	}
}
