package in.co.online.crime.Exception;

public class RecordNotFoundException {

}
