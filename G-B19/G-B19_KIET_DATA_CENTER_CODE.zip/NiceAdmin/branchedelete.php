<?php
include 'connection.php';
$id = $_GET['id'];
$deletequery = "delete from branches where branchid =$id";
$query = mysqli_query($con,$deletequery);
header('location:branches.php');

if($query){
    ?>
    <script>
        alert("Deleted");
    </script>
<?php
}else{
     ?>
    <script>
        alert("not deleted");
    </script>
    <?php
}

?>