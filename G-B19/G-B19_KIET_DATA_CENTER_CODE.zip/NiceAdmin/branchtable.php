<!-- Table with stripped rows -->
<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Course Name</th>
            <th scope="col">Branch Abbr</th>
            <th scope="col">Branch Name</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        include 'connection.php';

            $selectquery = " select * from branches";
            $query = mysqli_query($con,$selectquery);
            $nums = mysqli_num_rows($query);
            while($res = mysqli_fetch_array($query)){
                
                ?>
                <tr>
                    <th scope="row"><?php echo $res['branchid']?></th>
                    <td><?php echo $res['coursename']?></td>
                    <td><?php echo $res['branchabbr']?></td>
                    <td><?php echo $res['branchname']?></td>                    
                    <td>
                        <span class="btn btn-success"><i class="fa fa-eye" aria-hidden="true"></i></span>
                        <span class="btn btn-danger"><a class="delete" href="branchedelete.php?id=<?php echo $res['branchid'];?>"><i class="fa fa-trash" aria-hidden="true"></i></span>
                    </td>
                </tr>

        <?php
            }
        ?>
    </tbody>
</table>
<!-- End Table with stripped rows -->

