<?php
$server ="localhost";
$username ="root";
$password = "";
$dbname = "kietdatacenter";

$con = mysqli_connect($server,$username,$password,$dbname);

if($con){
    ?>
    <script>
        alert ('connected');
    </script>
   <?php 
}else{
    ?>
    <script>
        alert ('not connected');
    </script>
    <?php
}
?>
