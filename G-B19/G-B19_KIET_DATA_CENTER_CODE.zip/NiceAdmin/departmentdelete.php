<?php
include 'connection.php';
$id = $_GET['id'];
$deletequery = "delete from departmentcourse where courseid =$id";
$query = mysqli_query($con,$deletequery);
header('location:department.php');

if($query){
    ?>
    <script>
        alert("Deleted");
    </script>
<?php
}else{
     ?>
    <script>
        alert("not deleted");
    </script>
    <?php
}

?>