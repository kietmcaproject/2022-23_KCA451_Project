<?php
include 'connection.php';
$id = $_GET['id'];
$deletequery = "delete from staff where ID=$id";
$query = mysqli_query($con,$deletequery);
header('location:staff.php');

if($query){
    ?>
    <script>
        alert("Deleted");
    </script>
<?php
}else{
     ?>
    <script>
        alert("not deleted");
    </script>
    <?php
}

?>