
<!-- Table with stripped rows -->
<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Branchid</th>
            <th scope="col">Staffname</th>
            <th scope="col">Staffid</th>
            <th scope="col">Adharcard</th>
            <th scope="col">E-mail</th>
            <th scope="col">Doj</th>
            <th scope="col">Designationid</th>
            <th scope="col">Appointmentid</th>
            <th scope="col">Degreeid</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        include 'connection.php';

            $selectquery = " select * from staff ";
            $query = mysqli_query($con,$selectquery);
            $nums = mysqli_num_rows($query);
            while($res = mysqli_fetch_array($query)){
                
                ?>
                <tr>
                    <th scope="row"><?php echo $res['ID']?></th>
                    <td><?php echo $res['branchid']?></td>
                    <td><?php echo $res['staffname']?></td>
                    <td><?php echo $res['staffid']?></td>
                    <td><?php echo $res['adharcard']?></td>
                    <td><?php echo $res['email']?></td>
                    <td><?php echo $res['dateofjoining']?></td>
                    <td><?php echo $res['designationid']?></td>
                    <td><?php echo $res['appointmentid']?></td>
                    <td><?php echo $res['degreeid']?></td>
                    <td>
                        <span class="btn btn-success"><i class="fa fa-eye" aria-hidden="true"></i></span>
                        <span class="btn btn-danger"><a class="delete" href="staffdelete.php?id=<?php echo $res['ID'];?>"><i class="fa fa-trash" aria-hidden="true"></i></span>
                    </td>
                </tr>

        <?php
            }
        ?>
    </tbody>
</table>
<!-- End Table with stripped rows -->

