<?php echo '<pre>';?>
<h1>Index</h1>
<ul>
	<li><a href="">Chapter 1:What is HTML?</a><br></li>
	<li><a href="">Chapter 2:Write <br>HTML Using Notepador TextEdit</a><br></li>
	<li><a href="">Chapter 3:HTML <br>Headings</a><br></li>
	<li><a href="">Chapter 4:HTML <br>Attributes</a><br></li>
	<li><a href="">Chapter 5:HTML <br>Horizontal Rules</a><br></li>
	<li><a href="">Chapter 6:>HTML <br>Text Formatting</a><br></li>
	<li><a href="">Chapter 7:The HTML<?php $str='<q>'; echo htmlspecialchars($str); ?> element <br>defines a short <br>quotation.</a><br></li>
	<li><a href="">Chapter 8:HTML <br>Comment Tags</a><br></li>
	<li><a href="">Chapter 9:HTML <br>Lists</a><br></li>
	<li><a href="">Chapter 10:The <br><?php $str='<div>'; echo htmlspecialchars($str); ?> Element</a><br></li>
	<li><a href="">Chapter 11:HTML <br>Iframes</a><br></li>
	<li><a href="">Chapter 12:The <br><?php $str='<form>'; echo htmlspecialchars($str); ?> Element</a><br></li>
	<li><a href="">Chapter 13:The <br><?php $str='<select>'; echo htmlspecialchars($str); ?> Element</a><br></li>
	<li><a href="">Chapter 14:Input <br>Type Text</a><br></li>
</ul>
<?php echo '</pre>';?>