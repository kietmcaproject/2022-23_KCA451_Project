package com.example.chat_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
