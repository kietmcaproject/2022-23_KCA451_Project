import 'package:shared_preferences/shared_preferences.dart';

import '../utlis/app_constants/app_firebase_keys.dart';

class AppSharedPrefrence {
  AppSharedPrefrence._();
  static final AppSharedPrefrence _localDataObject = AppSharedPrefrence._();
  factory AppSharedPrefrence() {
    return _localDataObject;
  }

// getting all local data
  String? username;

  String? phoneNo;
  String? id;
  String? userProfile;
  String? description;

// getting user data from local storage
  Future<void> getCurrentUser() async {
    username = await getLocalData(FirebaseConstants.userName);
    id = await getLocalData(FirebaseConstants.id);
    description = await getLocalData(FirebaseConstants.descriptions);
    phoneNo = await getLocalData(FirebaseConstants.phoneNumber);
    userProfile = await getLocalData(FirebaseConstants.photoURL);
  }

// getting all user data and using further

  // saving local data
  Future<void> saveLocalData(
      {required String key, required String value}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString(key, value);
  }

// getting local data
  Future<String?> getLocalData(String key) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString(key);
  }
}
