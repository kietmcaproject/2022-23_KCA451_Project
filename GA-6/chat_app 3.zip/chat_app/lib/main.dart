import 'package:chat_app/firebase_options.dart';
import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/services/connectivity_services.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await AppSharedPrefrence().getCurrentUser();

  NetworkCheckConnectivity connectionStatus =
      NetworkCheckConnectivity.getInstance();
  connectionStatus.initialize();
  runApp(const FriendlyChat());
}

class FriendlyChat extends StatelessWidget {
  const FriendlyChat({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    FirebaseAuth auth = FirebaseAuth.instance;
    return ChangeNotifierProvider<AppCommonProvider>(
      create: (BuildContext context) => AppCommonProvider(),
      child: MaterialApp(
        theme: ThemeData(
            bottomSheetTheme: const BottomSheetThemeData(
                backgroundColor: AppColors.transparent)),
        debugShowCheckedModeBanner: false,
        initialRoute:
            (auth.currentUser != null && auth.currentUser!.emailVerified)
                ? GenratedRoutes.homseScreen
                : GenratedRoutes.login,
        onGenerateRoute: GenratedRoutes.generateRoute,
      ),
    );
  }
}
