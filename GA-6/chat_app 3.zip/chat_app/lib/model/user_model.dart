import 'package:firebase_auth/firebase_auth.dart';

// getting erro while signup or login
class UserDataModel {
  User? userCredentials;
  String? error;
  UserDataModel({this.userCredentials, this.error});
}
