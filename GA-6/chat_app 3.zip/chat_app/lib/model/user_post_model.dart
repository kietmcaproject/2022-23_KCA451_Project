import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

// post data model

class UserPostModel {
  FieldValue? time;
  List<String?>? postImage;
  String? message;
  String? userId;
  String? location;
  String? error;
  UserPostModel(
      {this.time,
      this.location,
      this.postImage,
      this.userId,
      this.error,
      this.message});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};

    data[FirebaseConstants.id] = userId;
    data[FirebaseConstants.message] = message;
    data[FirebaseConstants.postImages] = postImage;
    data[FirebaseConstants.sendTime] = time;
    data[FirebaseConstants.location] = location;

    return data;
  }
}
