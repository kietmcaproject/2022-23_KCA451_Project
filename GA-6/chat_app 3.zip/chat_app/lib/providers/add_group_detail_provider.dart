import 'dart:io';

import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/services/auth_services.dart';
import 'package:chat_app/utlis/common_methods.dart/common_methods.dart';
import 'package:flutter/material.dart';

class AddGroupDetailScreenProvider extends ChangeNotifier {
  final TextEditingController groupNameController = TextEditingController();
  final TextEditingController groupdescriptionController =
      TextEditingController();

  File? groupImage;
  bool enableButton = false;
  bool loader = false;
  String? photoUrl;

  void enableingButon() {
    enableButton = CommonMethods()
        .enableButton([groupdescriptionController, groupNameController]);
    notifyListeners();
  }

  // loader

  void loading() {
    loader = !loader;
    notifyListeners();
  }

  // getting image
  void getImage(File? image) {
    groupImage = image;
    notifyListeners();
  }

  String? groupId;
  // creating group
  Future<void> createGroup(
      {required List<String> users,
      required String groupdescription,
      required String groupName,
      required String? groupImageUrl}) async {
    groupId = await AuthServices().createChatGroup(
        groupAdmin: [AppSharedPrefrence().id!],
        userToChat: users,
        groupdescription: groupdescription,
        isGroup: true,
        groupName: groupName,
        groupImageUrl: groupImageUrl ?? '');
    AuthServices().chatWith(users, groupId!);
  }

// disposing controller
  @override
  void dispose() {
    groupNameController.dispose();
    groupdescriptionController.dispose();
    super.dispose();
  }
}
