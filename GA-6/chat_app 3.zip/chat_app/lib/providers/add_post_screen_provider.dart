import 'dart:io';

import 'package:chat_app/utlis/common_methods.dart/common_methods.dart';

import 'package:flutter/material.dart';

class AddPostScreenProvider extends ChangeNotifier {
  final TextEditingController postController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final GlobalKey<FormState> postFormKey = GlobalKey<FormState>();
  bool enableButton = false;
  bool loader = false;
  String? photoUrl;
  File? imageFile;
  // getting image
  void getImage(File? image) {
    imageFile = image;
    notifyListeners();
  }

// loader for image uplading
  void imageLoaderTrue() {
    loader = true;
    notifyListeners();
  }

// notify imageLoader
  void imageLoaderFalse() {
    loader = false;
    notifyListeners();
  }

// saving photUrl
  void getPhotoUrl(String? url) {
    photoUrl = url;
    notifyListeners();
  }

// enabling button
  void onTextFieldChanged() {
    enableButton = CommonMethods().enableButton(
      [postController, locationController],
    );
    notifyListeners();
  }
  // disposing controllers

  @override
  void dispose() {
    locationController.dispose();
    postController.dispose();
    super.dispose();
  }
}
