import 'dart:io';
import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/model/user_post_model.dart';
import 'package:chat_app/services/connectivity_services.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

class AppCommonProvider extends ChangeNotifier {
  List<Map<String, dynamic>?>? allUsers;
  Map<dynamic, dynamic>? currentUsers;

// getting all user data and using further
  void getAllData(List<Map<String, dynamic>?>? usersData) {
    allUsers = usersData;
  }

// searching data from all users
  List<Map<String, dynamic>?> searchedData = [];

  void searchingData(String? text) {
    searchedData = [];

    for (int i = 0; i < allUsers!.length; i++) {
      if (allUsers?[i]?[FirebaseConstants.userName]
          .startsWith(RegExp(text!.trim(), caseSensitive: false))) {
        searchedData.add(allUsers![i]);
      }
    }
  }

//
  bool connectivity = false;

  void _connectionChanged(dynamic hasConnection) {
    connectivity = !hasConnection;
    notifyListeners();
  }

//
// checking connection
  void checkingConnection() {
    NetworkCheckConnectivity.getInstance()
        .connectionChange
        .listen(_connectionChanged);
  }
//posted user data

  Map<String, dynamic>? postedUserData(String id, int index) {
    if (FirebaseConstants.id == AppSharedPrefrence().id) {
      return {
        FirebaseConstants.postUserProfile: AppSharedPrefrence().userProfile,
        FirebaseConstants.postUserName: AppSharedPrefrence().username
      };
    } else {
      return allUsers![index];
    }
  }

  // Upload image to the server and geting image link
  Future<String?> uploadImageFile(
    BuildContext context,
    String userName,
    File image,
  ) async {
    String photoUrl = '';

    FirebaseStorage firebaseStorage = FirebaseStorage.instance;

    Reference reference =
        firebaseStorage.ref().child('$userName/${image.path.split('/').last}');
    UploadTask uploadTask = reference.putFile(image);
    try {
      TaskSnapshot snapshot = await uploadTask.whenComplete(() => {});
      photoUrl = await snapshot.ref.getDownloadURL();

      return photoUrl;
    } catch (e) {
      rethrow;
    }
  }

// adding post to the firebase
  Future<void> addPost(UserPostModel userPostData) async {
    try {
      await FirebaseFirestore.instance
          .collection(FirebaseConstants.postPath)
          .doc()
          .set(userPostData.toJson());
    } catch (e) {
      userPostData.error = e.toString();
    }
  }

// picking image from device
  Future<File?> imagePicking(BuildContext context) async {
    try {
      ImagePicker picker = ImagePicker();

      XFile? imageData = await picker.pickImage(source: ImageSource.gallery);

      if (imageData == null) {
        return null;
      }
      return File(
        imageData.path,
      );
    } on PlatformException catch (e) {
      AppCommonSnackBar().appCommonSnackbar(context, AppStrings.errorToLoad);
    }
    return null;
  }
}
