import 'dart:developer';
import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/services/auth_services.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ChatDetailScreenProvider extends ChangeNotifier {
  TextEditingController chatTextController = TextEditingController();
  User? currentUser = FirebaseAuth.instance.currentUser;
  final FirebaseFirestore _firebaseFirestore = FirebaseFirestore.instance;
  final AuthServices _authServices = AuthServices();
// chat with the user detail
// who is chating with whom

  String? groupId;
  Future<void> addChatUser({
    required List<String>? listOfMembers,
    required String? chatRoomId,
    required String? chatWithUser,
    required BuildContext context,
  }) async {
// creating and checking chatroom is exist
    try {
      groupId = chatRoomId ??
          await _authServices.createChatGroup(
            groupAdmin: null,
            lastMessage: chatTextController.text.trim(),
            userToChat: [AppSharedPrefrence().id!, chatWithUser!],
            sendBy: currentUser!.uid,
            isGroup: false,
          );
      notifyListeners();
      // adding group data

// chatting with the user chatid save to both chatters
      (chatWithUser == null || chatWithUser.isEmpty)
          ? (listOfMembers == null || listOfMembers.isEmpty)
              ? null
              : (_authServices.chatWith(listOfMembers, groupId!))
          : _authServices
              .chatWith([AppSharedPrefrence().id!, chatWithUser], groupId!);

// sending msg to the chatroom

      _authServices.sendMessage(
          chatRoomId: groupId!, message: chatTextController.text.trim());

      chatTextController.clear();
    } catch (e) {
      log(e.toString());
    }
  }

  // checing who is messaging
  bool isME(String msgUser) {
    if (msgUser == currentUser!.uid) {
      return true;
    } else {
      return false;
    }
  }

  // getting messages from firebase
  Stream<QuerySnapshot<Map<String, dynamic>>>? getMessages(String? groupId) {
    return _firebaseFirestore
        .collection(FirebaseConstants.chatRoompath)
        .doc(groupId)
        .collection(FirebaseConstants.chats)
        .orderBy(FirebaseConstants.sendTime, descending: true)
        .snapshots();
  }

  // time
  String? chatTime(Timestamp timestamp) {
    DateTime date = timestamp.toDate();

    return '${date.hour}:${date.minute}';
  }
  //disposing

  @override
  void dispose() {
    chatTextController.dispose();
    super.dispose();
  }
}
