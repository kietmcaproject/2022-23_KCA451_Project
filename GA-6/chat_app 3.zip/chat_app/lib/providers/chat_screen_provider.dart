// ignore_for_file: curly_braces_in_flow_control_structures

import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/services/auth_services.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ChatScreenProvider extends ChangeNotifier {
  final GlobalKey<FormState> messageFormKey = GlobalKey<FormState>();
  final TextEditingController messageSearchController = TextEditingController();
  User? currentUser = FirebaseAuth.instance.currentUser;
  List<String>? chatUser;

  // chat with user
  String? _chatWithUSerId(List<String> userIds) {
    for (int i = 0; i < userIds.length; i++) {
      if (userIds[i] != currentUser!.uid) {
        return userIds[i];
      }
    }
    return null;
  }

// getting list of users which current user chat
  Stream<List<Map<String, dynamic>?>?> getUSerDetail() {
// getting group ids from current user collection
    Stream<List<String>?> userschatRoomIds = (FirebaseFirestore.instance
            .collection(FirebaseConstants.userPath)
            .doc(currentUser!.uid)
            .collection(FirebaseConstants.chatUserList)
            .orderBy(FirebaseConstants.sendTime, descending: true)
            .snapshots())
        .map((event) {
      if (event.docs.isEmpty) {
        return null;
      }
      return event.docs
          .map((e) => e.data()[FirebaseConstants.groupId] as String)
          .toList();
    });

// entering to the chatrrom collection and get all rooms data from chat room from id of current user group list ids
    Stream<List<DocumentSnapshot<Map<String, dynamic>>>?> groupData =
        userschatRoomIds.asyncMap((event) async {
      List<DocumentSnapshot<Map<String, dynamic>>>? chatGroupData =
          event == null
              ? null
              : await Future.wait(event.map((e) => (FirebaseFirestore.instance
                  .collection(FirebaseConstants.chatRoompath)
                  .doc(e)
                  .get())));

      return chatGroupData;
    });
    // retunring group data if it is group otherwise search user from user list and add data to it
    Stream<List<Map<String, dynamic>?>?> chatUsers =
        groupData.asyncMap((event) async {
      List<Map<String, dynamic>?>? groupUsersData = (event == null)
          ? null
          : await Future.wait(event.map((e) async {
              if (e.data()?[FirebaseConstants.isGroup] == null ||
                  e.data()![FirebaseConstants.isGroup] == false) {
                Map<String, dynamic>? chatUser = await AuthServices().getUser(
                    _chatWithUSerId(
                        (e.data()?[FirebaseConstants.userPath] as List)
                            .cast<String>())!);

                chatUser?.addAll({
                  FirebaseConstants.chatRoomId: e.id,
                  FirebaseConstants.lastMessage:
                      e.data()?[FirebaseConstants.lastMessage],
                  FirebaseConstants.sendby: e.data()?[FirebaseConstants.sendby],
                  FirebaseConstants.sendTime:
                      e.data()?[FirebaseConstants.sendTime],
                });

                return chatUser;
              } else {
                Map<String, dynamic>? groupData = e.data();
                groupData?.addAll({FirebaseConstants.chatRoomId: e.id});

                return groupData;
              }
            }));

      return groupUsersData;
    });

    return chatUsers;
  }

// last sender
  String? lastSender(
      {required String? id,
      required List<Map<String, dynamic>?>? allUsers,
      required isGroup}) {
    if (isGroup == null || isGroup == false) {
      return null;
    } else if (id == null || id == '') {
      return null;
    } else {
      if (id == AppSharedPrefrence().id) {
        return AppStrings.you;
      } else {
        return (allUsers?.firstWhere((element) =>
            element?[FirebaseConstants.id] == id))![FirebaseConstants.userName];
      }
    }
  }

// searching user data
  bool searching = false;
  void searchStart() {
    searching = true;
    notifyListeners();
  }

  void searchCnacel() {
    searching = false;
    notifyListeners();
  }

  List<Map<String, dynamic>?>? chatWithUser;

  void getChatWithUser(List<Map<String, dynamic>?>? data) {
    chatWithUser = data;
  }

  List<Map<String, dynamic>> get searchedData {
    List<Map<String, dynamic>> searchedData = [];
    for (int i = 0; i < chatWithUser!.length; i++) {
      if (chatWithUser![i]![FirebaseConstants.userName].startsWith(
          RegExp(messageSearchController.text.trim(), caseSensitive: false))) {
        searchedData.add(chatWithUser![i]!);
      }
    }
    return searchedData;
  }

// disposing
  @override
  void dispose() {
    messageSearchController.dispose();
    super.dispose();
  }
}
