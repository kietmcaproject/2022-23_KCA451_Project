import 'package:chat_app/utlis/common_methods.dart/common_methods.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../utlis/app_helper/app_strings.dart';

class ForgotPasswordScreenProvider extends ChangeNotifier {
  final TextEditingController emailController = TextEditingController();
  final GlobalKey<FormState> forgotFormKey = GlobalKey<FormState>();
  bool enableButton = false;
  bool buttonLoader = false;
// reset forgot password
  Future resetPassword({required BuildContext context}) async {
    FirebaseAuth auth = FirebaseAuth.instance;
    buttonLoader = true;
    notifyListeners();
    await auth
        .sendPasswordResetEmail(email: emailController.text)
        .then((value) {
      AppCommonSnackBar().appCommonSnackbar(
          context, '${AppStrings.passwordLinkSendTo}${emailController.text}');
      Navigator.pop(context);
    }).catchError((e) {
      AppCommonSnackBar()
          .appCommonSnackbar(context, AppStrings.passwordNotUpdated);
    });
    buttonLoader = false;
    notifyListeners();
  }

// enabling button
  void onChanged() {
    enableButton = CommonMethods().enableButton([emailController]);
    notifyListeners();
  }

// disposing
  @override
  void dispose() {
    emailController.dispose();
    super.dispose();
  }
}
