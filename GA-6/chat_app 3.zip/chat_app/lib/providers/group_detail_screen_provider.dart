// ignore_for_file: use_build_context_synchronously

import 'dart:io';
import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/services/auth_services.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:flutter/material.dart';

class GroupDeatilScreenProvider extends ChangeNotifier {
  final TextEditingController groupNameController = TextEditingController();
  final TextEditingController groupdescriptionController =
      TextEditingController();
  final AuthServices _authServices = AuthServices();

  bool editiableGroupName = false;
  bool editiableGroupdescription = false;
  bool editablePhoto = false;

  bool loader = false;
  bool isAlreadyAdmin = false;

  File? image;
  void imageGetter(File? imageFile) {
    image = imageFile;
    notifyListeners();
  }

  //
  void editGroupName() {
    editiableGroupName = !editiableGroupName;
    notifyListeners();
  }

  void editPhoto() {
    editablePhoto = !editablePhoto;
    notifyListeners();
  }

  void editGroupdescription() {
    editiableGroupdescription = !editiableGroupdescription;
    notifyListeners();
  }

  bool isAdmin = false;
  bool checkingAdmin(List<String> adminList, String id) {
    if (adminList.contains(id)) {
      return true;
    } else {
      return false;
    }
  }

  bool build = false;
  void onInit(
      {required String groupName,
      required List<String> adminList,
      required String groupdescription}) {
    if (!build) {
      groupNameController.text = groupName;
      groupdescriptionController.text = groupdescription;
      build = true;
    }
    isAdmin = checkingAdmin(adminList, AppSharedPrefrence().id!);
  }

// adding admin
  Future<void> addAdmin(
      {required List<String> adminList,
      required String chatRoomId,
      required BuildContext context}) async {
    loader = true;
    notifyListeners();
    bool added = await _authServices.updateDetailWithCollectionAndDocId(
      collectionId: FirebaseConstants.chatRoompath,
      chatRoomId: chatRoomId,
      data: {FirebaseConstants.groupAdmin: adminList},
    );
    loader = false;
    notifyListeners();
    if (!added) {
      AppCommonSnackBar().appCommonSnackbar(context, AppStrings.serverError);
      // AppCommonSnackBar()
      //     .appCommonSnackbar(context, AppStrings.groupAdminAddedSuccessfully);
    }
  }

// removing admin
  Future<void> removeAdmin(
      {required List<String> adminList,
      required String chatRoomId,
      required BuildContext context}) async {
    loader = true;
    notifyListeners();

    bool removed = await _authServices.updateDetailWithCollectionAndDocId(
      collectionId: FirebaseConstants.chatRoompath,
      chatRoomId: chatRoomId,
      data: {FirebaseConstants.groupAdmin: adminList},
    );
    loader = false;
    notifyListeners();
    if (!removed) {
      AppCommonSnackBar().appCommonSnackbar(context, AppStrings.serverError);
    }
  }

  //  admin add group name or description
  Future<void> updateGroupNameOrdescription(
      {required String data,
      required String chatRoomId,
      List<String>? members,
      required String field,
      required BuildContext context}) async {
    loader = true;
    notifyListeners();
    bool text = await _authServices.updateDetailWithCollectionAndDocId(
      collectionId: FirebaseConstants.chatRoompath,
      chatRoomId: chatRoomId,
      data: {field: data},
    );
    if (field == FirebaseConstants.userName) {
      (members == null || members.isEmpty)
          ? null
          : _authServices.chatWith(members, chatRoomId);
      _authServices.sendMessage(
          chatRoomId: chatRoomId,
          message: "Group name changed by ${AppSharedPrefrence().username}");
    }
    loader = false;
    notifyListeners();
    if (text) {
      AppCommonSnackBar()
          .appCommonSnackbar(context, AppStrings.textEditSuccessfully);
    } else {
      AppCommonSnackBar().appCommonSnackbar(context, AppStrings.serverError);
    }
  }

  // admin edit group image

  bool imageLoader = false;
  Future<void> updateGroupImage(
      {required String imaegUrl,
      required String chatRoomId,
      required BuildContext context}) async {
    imageLoader = true;
    notifyListeners();
    bool imageUpload = await _authServices.updateDetailWithCollectionAndDocId(
      collectionId: FirebaseConstants.chatRoompath,
      chatRoomId: chatRoomId,
      data: {FirebaseConstants.photoURL: imaegUrl},
    );
    imageLoader = false;
    notifyListeners();
    if (imageUpload) {
      AppCommonSnackBar().appCommonSnackbar(context, AppStrings.imageUploaded);
    } else {
      AppCommonSnackBar().appCommonSnackbar(context, AppStrings.serverError);
    }
  }
// admin remove user from group

  Future<void> removeUserFromGroup(
      {required BuildContext context,
      required String groupId,
      required String userId,
      required Map<String, dynamic> data}) async {
    loader = true;
    notifyListeners();
    bool removeFromUserList = await _authServices.deleteDataByDocId(
        collection: FirebaseConstants.userPath,
        otherUserId: userId,
        chatRoomId: groupId,
        otherCollection: FirebaseConstants.chatUserList);
    bool remove = removeFromUserList
        ? await _authServices.updateDetailWithCollectionAndDocId(
            collectionId: FirebaseConstants.chatRoompath,
            chatRoomId: groupId,
            data: data)
        : false;
    loader = false;
    notifyListeners();
    if (!remove) {
      AppCommonSnackBar().appCommonSnackbar(context, AppStrings.serverError);
    }
  }

  // exit from group
  Future<void> exitFromGroup(
      {required BuildContext context,
      required String groupId,
      // required String userId,
      required Map<String, dynamic> data}) async {
    loader = true;
    notifyListeners();

    bool exitGroup = await _authServices.deleteDataByDocId(
        collection: FirebaseConstants.userPath,
        otherUserId: AppSharedPrefrence().id,
        chatRoomId: groupId,
        otherCollection: FirebaseConstants.chatUserList);
    bool isExit = exitGroup
        ? await _authServices.updateDetailWithCollectionAndDocId(
            collectionId: FirebaseConstants.chatRoompath,
            chatRoomId: groupId,
            data: data)
        : false;

    if (isExit) {
      Navigator.pushNamedAndRemoveUntil(
          context, GenratedRoutes.chatScreen, (route) => false);
    } else {
      AppCommonSnackBar().appCommonSnackbar(context, AppStrings.serverError);
    }

    loader = false;
    notifyListeners();
  }

  // dispossing

  @override
  void dispose() {
    groupNameController.dispose();
    groupdescriptionController.dispose();

    super.dispose();
  }
}
