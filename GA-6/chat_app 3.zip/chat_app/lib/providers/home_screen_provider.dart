// ignore_for_file: use_build_context_synchronously

import 'package:chat_app/services/auth_services.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class HomeScreenProvider extends ChangeNotifier {
  final User? _currentUser = FirebaseAuth.instance.currentUser;
  final AuthServices _authServices = AuthServices();
  // getting all user data and displaying as a story
  Stream<QuerySnapshot<Map<String, dynamic>>> getStory() {
    return FirebaseFirestore.instance
        .collection(FirebaseConstants.userPath)
        .where(FirebaseConstants.id, isNotEqualTo: _currentUser!.uid)
        .snapshots();
  }

// getting post data
  Stream<List<Map>> getpost() {
    // getting list of post and id of post users
    Stream<List<Map<String, dynamic>>> postData = FirebaseFirestore.instance
        .collection(FirebaseConstants.postPath)
        .orderBy(FirebaseConstants.sendTime, descending: true)
        .snapshots()
        .asyncMap((event) {
      return event.docs.map((e) {
        Map<String, dynamic> postData = e.data();
        postData.addAll({FirebaseConstants.postId: e.id});
        return postData;
      }).toList();
    });
// getting postusers data and adding to post data
    Stream<List<Map<String, dynamic>>> postUserData =
        postData.asyncMap((event) async {
      return await Future.wait(event.map((post) async {
        Map<String, dynamic>? userData =
            await _authServices.getUser(post[FirebaseConstants.id]);
        post.addAll(userData!);
        return post;
      }).toList());
    });
    return postUserData;
  }

  //
  bool openMenu = false;

  void menuBar() {
    openMenu = !openMenu;
    notifyListeners();
  }

  // deleting post by current user
  bool postDeleteLoader = false;
  Future<void> deletPost(
      {required String id, required BuildContext context}) async {
    // postDeleteLoader = true;
    notifyListeners();
    bool postDeleted = await _authServices.deleteDataByDocId(
        collection: FirebaseConstants.postPath, chatRoomId: id);
    // postDeleteLoader = false;
    notifyListeners();
    if (postDeleted) {
      AppCommonSnackBar()
          .appCommonSnackbar(context, AppStrings.postDeletedSuccesfully);
    } else {
      AppCommonSnackBar().appCommonSnackbar(context, AppStrings.errorToDelete);
    }
  }
}
