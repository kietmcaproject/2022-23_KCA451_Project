// ignore_for_file: use_build_context_synchronously

import 'package:chat_app/app_shared_prefreneces/local_data.dart';

import 'package:chat_app/model/user_model.dart';
import 'package:chat_app/services/auth_services.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/common_methods.dart/common_methods.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class LoginScreenProvider extends ChangeNotifier {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();
  final AppSharedPrefrence _localData = AppSharedPrefrence();
  bool buttonLoader = false;
  bool obscure = true;
  bool enableButton = false;
// obscurring text
  void obscureText() {
    obscure = !obscure;
    notifyListeners();
  }

// enabling button
  void onTextFieldChanged() {
    enableButton = CommonMethods().enableButton(
      [emailController, passwordController],
    );
    notifyListeners();
  }

  final AuthServices _authServices = AuthServices();

  // user login
  Future<void> userLogin(
    BuildContext context,
  ) async {
    buttonLoader = true;
    notifyListeners();
    UserDataModel? userData = await _authServices.login(
        emailController.text.trim(), passwordController.text.trim());

    buttonLoader = false;
    notifyListeners();
    if (userData.userCredentials == null || userData.error != null) {
      AppCommonSnackBar().appCommonSnackbar(context, userData.error.toString());
    } else if (!userData.userCredentials!.emailVerified) {
      AppCommonSnackBar()
          .appCommonSnackbar(context, AppStrings.emailIsNotVerified);
    } else {
      Map<String, dynamic>? currentUser = (await FirebaseFirestore.instance
              .collection(FirebaseConstants.userPath)
              .doc(userData.userCredentials?.uid)
              .get())
          .data();

      if (currentUser == null || currentUser.isEmpty) {
        AppCommonSnackBar().appCommonSnackbar(context, AppStrings.userNotFound);

        await userData.userCredentials!.delete();
        // saving user data locally
      } else {
        await _localData.saveLocalData(
            key: FirebaseConstants.id,
            value: currentUser[FirebaseConstants.id]);
        await _localData.saveLocalData(
            key: FirebaseConstants.descriptions,
            value: currentUser[FirebaseConstants.descriptions]);
        await _localData.saveLocalData(
            key: FirebaseConstants.userName,
            value: currentUser[FirebaseConstants.userName]);
        await _localData.saveLocalData(
            key: FirebaseConstants.phoneNumber,
            value: currentUser[FirebaseConstants.phoneNumber]);
        await _localData.saveLocalData(
            key: FirebaseConstants.photoURL,
            value: currentUser[FirebaseConstants.photoURL]);
        AppCommonSnackBar()
            .appCommonSnackbar(context, AppStrings.loginSuccessful);
        Navigator.pushNamed(context, GenratedRoutes.homseScreen);
      }
    }
  }

  // login with google
  Future<void> googleLogin(BuildContext context) async {
    buttonLoader = true;
    notifyListeners();
    UserDataModel dataModel = await _authServices.handleGoogleSignIn();
    buttonLoader = false;
    notifyListeners();
    if (dataModel.userCredentials != null) {
      AppCommonSnackBar()
          .appCommonSnackbar(context, AppStrings.loginSuccessful);
      await AppSharedPrefrence().getCurrentUser();
      Navigator.pushReplacementNamed(context, GenratedRoutes.homseScreen);
    } else {
      AppCommonSnackBar()
          .appCommonSnackbar(context, dataModel.error.toString());
    }
  }

  // disposing controller
  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }
}
