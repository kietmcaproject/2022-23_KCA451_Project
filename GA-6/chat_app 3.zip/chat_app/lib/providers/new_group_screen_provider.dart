// ignore_for_file: use_build_context_synchronously

import 'package:chat_app/services/auth_services.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:flutter/material.dart';

class NewGroupScreenProvider extends ChangeNotifier {
  List<String> groupChatWithUser = [];
  List<Map<String, dynamic>?> allUsers = [];

  void getAllUsersdata(List<Map<String, dynamic>?> data) {
    allUsers = data;
  }

// add chating user for group
  void chatWithUser(String chatWithUserId, BuildContext context) {
    if (groupChatWithUser.length > 10) {
      AppCommonSnackBar()
          .appCommonSnackbar(context, AppStrings.onlyTenUSersCanBeInAGroup);
    } else {
      if (groupChatWithUser.contains(chatWithUserId)) {
        removeChatUser(chatWithUserId);
      } else {
        groupChatWithUser.add(chatWithUserId);
      }
      notifyListeners();
    }
  }

// removing chat users
  void removeChatUser(String selectedUSerID) {
    groupChatWithUser.remove(selectedUSerID);
    notifyListeners();
  }

  bool isAllReadyInGroup(
      {required List<String?> groupMembers, required String? id}) {
    if (groupMembers.isEmpty) {
      return false;
    } else {
      if (groupMembers.contains(id)) {
        return true;
      } else {
        return false;
      }
    }
  }

  bool loader = false;
// add member to the group
  Future<void> addMemberToGroup(
      {required BuildContext context,
      required Map<String, dynamic> data,
      required List<String> lastAdded,
      required String chatRoomId}) async {
    final AuthServices authServices = AuthServices();
    loader = true;
    notifyListeners();
    bool addMember = await authServices.updateDetailWithCollectionAndDocId(
        collectionId: FirebaseConstants.chatRoompath,
        chatRoomId: chatRoomId,
        data: data);
    await authServices.chatWith(lastAdded, chatRoomId);
    loader = false;
    notifyListeners();
    if (addMember) {
      AppCommonSnackBar()
          .appCommonSnackbar(context, AppStrings.memberAddedSuccessfully);
      Navigator.pop(context);
    } else {
      AppCommonSnackBar().appCommonSnackbar(context, AppStrings.serverError);
    }
  }

// selected users
  bool selected(String? id) {
    return groupChatWithUser.contains(id);
  }
}
