import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:flutter/material.dart';

class SearchedScreenProvider extends ChangeNotifier {
  final TextEditingController searchController = TextEditingController();
  final GlobalKey<FormState> searchFormKey = GlobalKey<FormState>();
  List<Map<String, dynamic>?>? allUsers;

  // getting all data
  void getAllData(
    List<Map<String, dynamic>?>? data,
  ) {
    allUsers = data;
  }

  bool searched = false;
  void onChanegd() {
    (searchController.text.isEmpty || searchController.text == '')
        ? searched = false
        : searched = true;
    notifyListeners();
  }

// get searched data getter
  List<Map<String, dynamic>> get searchedData {
    List<Map<String, dynamic>> searchedData = [];
    for (int i = 0; i < allUsers!.length; i++) {
      if (allUsers![i]![FirebaseConstants.userName].startsWith(
          RegExp(searchController.text.trim(), caseSensitive: false))) {
        searchedData.add(allUsers![i]!);
      }
    }
    return searchedData;
  }

// disposing controller
  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }
}
