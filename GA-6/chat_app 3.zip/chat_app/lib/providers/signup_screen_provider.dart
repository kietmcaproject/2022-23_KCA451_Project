// ignore_for_file: use_build_context_synchronously
import 'dart:io';
import 'package:chat_app/model/user_model.dart';
import 'package:chat_app/services/auth_services.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/common_methods.dart/common_methods.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class SignUpScreenProvider extends ChangeNotifier {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController phoneNoController = TextEditingController();
  final GlobalKey<FormState> signUpFormKey = GlobalKey<FormState>();

  File? imageFile;
// getting image file
  void getImage(File? image) {
    imageFile = image;
    notifyListeners();
  }

  bool buttonLoader = false;
  bool enableButton = false;
  bool imageLoader = false;
  // enabling button
  void onTextFieldChanged() {
    enableButton = CommonMethods().enableButton(
      [emailController, passwordController, phoneNoController, nameController],
    );
    notifyListeners();
  }

// creating user on firebase
  Future<void> addUser(
    FirebaseAuth auth,
    BuildContext context,
  ) async {
    AuthServices authServices = AuthServices();
    buttonLoader = true;
    notifyListeners();
    UserDataModel? userdata = await authServices.signUp(
      email: emailController.text,
      password: passwordController.text,
    );
// saving locally data

    (userdata?.userCredentials == null || userdata?.error != null)
        ? AppCommonSnackBar()
            .appCommonSnackbar(context, userdata!.error.toString())
        : Navigator.pushNamed(context, GenratedRoutes.verificationScreen,
            arguments: {
                FirebaseConstants.userName: nameController.text,
                FirebaseConstants.phoneNumber: phoneNoController.text,
                FirebaseConstants.descriptions: descriptionController.text,
                FirebaseConstants.imageFile: imageFile
              });

    buttonLoader = false;
    notifyListeners();
  }

  // obscure text
  bool obscure = true;
  void obscureText() {
    obscure = !obscure;
    notifyListeners();
  }

  // disposing controller
  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    descriptionController.dispose();
    phoneNoController.dispose();
    super.dispose();
  }
}
