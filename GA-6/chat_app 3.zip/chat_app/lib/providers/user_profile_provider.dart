// ignore_for_file: use_build_context_synchronously

import 'dart:io';
import 'package:chat_app/firebase_options.dart';
import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserProfileScreenProvider extends ChangeNotifier {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController phoneNoController = TextEditingController();
  final AppSharedPrefrence _localData = AppSharedPrefrence();
  bool logoutLoader = false;
  bool imageLoader = false;
  String? photoUrl;
  File? imageFile;
  void getImage(File? image) {
    imageFile = image;
    notifyListeners();
  }

  void imageLoading() {
    imageLoader = !imageLoader;
    notifyListeners();
  }

  void getPhotoUrl(String? url) {
    photoUrl = url;
    notifyListeners();
  }

  bool edit = false;
  bool build = false;
  void onInt({
    String? username,
    String? description,
    String? phoneNo,
  }) {
    if (!build) {
      nameController.text = (username == '' || username == null)
          ? AppStrings.addUserName
          : username;
      descriptionController.text = (description == null ||
              description.isEmpty ||
              description == '' ||
              description == 'null')
          ? AppStrings.addUserdescription
          : description;
      phoneNoController.text = (phoneNo == '' || phoneNo == null)
          ? AppStrings.addUserPhoneNo
          : phoneNo;
      build = true;
    }
  }

// updating user profile
  Future<void> update(String id, Map<String, dynamic> data) async {
    // saving data to local
    await _localData.saveLocalData(
        key: FirebaseConstants.id, value: data[FirebaseConstants.id]);
    await _localData.saveLocalData(
        key: FirebaseConstants.descriptions,
        value: data[FirebaseConstants.descriptions]);
    await _localData.saveLocalData(
        key: FirebaseConstants.userName,
        value: data[FirebaseConstants.userName]);
    await _localData.saveLocalData(
        key: FirebaseConstants.phoneNumber,
        value: data[FirebaseConstants.phoneNumber]);
    await _localData.saveLocalData(
        key: FirebaseConstants.photoURL,
        value: data[FirebaseConstants.photoURL]);
    try {
      await FirebaseFirestore.instance
          .collection(FirebaseConstants.userPath)
          .doc(id)
          .update(data);
    } catch (e) {
      print(e);
    }
  }

  void editable() {
    edit = true;
    notifyListeners();
  }

  void nonEditable() {
    edit = false;
    notifyListeners();
  }

// loggin out from app
  Future<bool> logout() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();

    try {
      GoogleSignIn googleSignIn = GoogleSignIn(
          clientId: DefaultFirebaseOptions.currentPlatform.iosClientId);

      if (await googleSignIn.isSignedIn()) {
        await preferences.clear();
        logoutLoader = true;
        notifyListeners();
        await FirebaseAuth.instance.signOut();

        await googleSignIn.disconnect();
        await googleSignIn.signOut();
        logoutLoader = false;
        notifyListeners();
      } else {
        await preferences.clear();
        logoutLoader = true;
        notifyListeners();
        await FirebaseAuth.instance.signOut();
        logoutLoader = false;
        notifyListeners();
      }

      return true;
    } catch (e) {
      return false;
    }
  }

// disposing controllers
  @override
  void dispose() {
    nameController.dispose();
    descriptionController.dispose();
    phoneNoController.dispose();
    super.dispose();
  }
}
