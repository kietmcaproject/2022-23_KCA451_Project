// ignore_for_file: use_build_context_synchronously

import 'package:chat_app/app_shared_prefreneces/local_data.dart';

import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/providers/add_group_detail_provider.dart';
import 'package:chat_app/screens/home_screen/user_name_with_image_widget.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_common_appbar.dart';
import 'package:chat_app/utlis/widgets/app_netowrk_error.dart';
import 'package:chat_app/utlis/widgets/common_text_form_field.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddGroupDetailScreen extends StatelessWidget {
  final List<String> chatWithUserList;
  const AddGroupDetailScreen({Key? key, required this.chatWithUserList})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    AppCommonProvider appCommonProvider =
        Provider.of<AppCommonProvider>(context, listen: true);
    appCommonProvider.checkingConnection();
    return Consumer<AddGroupDetailScreenProvider>(
      builder: (context, groupDetailScreenConsumer, child) {
        return AppCommonAppBar(
          text: (AppStrings.addGroupDetail),
          body: (appCommonProvider.connectivity)
              ? const AppNetworkErrorWidget()
              : groupDetailScreenConsumer.loader
                  ? const Center(
                      child: CircularProgressIndicator(
                          color: AppColors.primaryColor),
                    )
                  : Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 15, horizontal: 10),
                      child: ListView(
                        // padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                        // crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          groupDetailScreenConsumer.groupImage == null
                              ? GestureDetector(
                                  onTap: () async {
                                    groupDetailScreenConsumer.getImage(
                                        await appCommonProvider
                                            .imagePicking(context));
                                  },
                                  child: Container(
                                      padding: const EdgeInsets.all(28),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                          color: AppColors.primaryColor
                                              .withOpacity(0.6),
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                              color: AppColors.grey800)),
                                      child:
                                          const Icon(Icons.camera_alt_rounded)),
                                )
                              : Container(
                                  padding: const EdgeInsets.all(40),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: FileImage(
                                              groupDetailScreenConsumer
                                                  .groupImage!),
                                          fit: BoxFit.fill),
                                      color: AppColors.primaryColor
                                          .withOpacity(0.6),
                                      shape: BoxShape.circle,
                                      border:
                                          Border.all(color: AppColors.grey800)),
                                ),
                          SizedBox(height: height * 0.05),
                          Form(
                            onChanged: groupDetailScreenConsumer.enableingButon,
                            child: Column(
                              children: [
                                CommonTextFormField(
                                    labelText: AppStrings.groupName,
                                    obscure: false,
                                    controller: groupDetailScreenConsumer
                                        .groupNameController,
                                    keyboardType: TextInputType.multiline,
                                    textInputAction: TextInputAction.newline),
                                SizedBox(height: height * 0.05),
                                CommonTextFormField(
                                    labelText: AppStrings.description,
                                    obscure: false,
                                    controller: groupDetailScreenConsumer
                                        .groupdescriptionController,
                                    keyboardType: TextInputType.multiline,
                                    textInputAction: TextInputAction.newline),
                              ],
                            ),
                          ),
                          SizedBox(height: height * 0.05),
                          Text(
                              '${AppStrings.participants}: ${chatWithUserList.length}',
                              style: CommonTextStyles.white18w500.copyWith(
                                  color: AppColors.grey800,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400)),
                          SizedBox(
                            height: height * 0.02,
                          ),
                          SizedBox(
                              height: height * 0.4,
                              child: GridView.builder(
                                  gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                    childAspectRatio: 0.9,
                                    crossAxisCount: 4,
                                  ),
                                  itemCount: chatWithUserList.length,
                                  itemBuilder: (context, index) {
                                    Map<dynamic, dynamic>? selectedUSerData = {
                                      FirebaseConstants.userName:
                                          AppSharedPrefrence().username,
                                      FirebaseConstants.photoURL:
                                          AppSharedPrefrence().userProfile,
                                    };
//TODO
                                    try {
                                      selectedUSerData = appCommonProvider
                                          .allUsers!
                                          .firstWhere((userMap) =>
                                              userMap![FirebaseConstants.id] ==
                                              chatWithUserList[index]);
                                    } on StateError {
                                      const Center(
                                          child: CircularProgressIndicator(
                                        color: AppColors.primaryColor,
                                      ));
                                    }

                                    return UserNameWithImageWidget(
                                      userName: selectedUSerData?[
                                          FirebaseConstants.userName],
                                      userProfile: selectedUSerData?[
                                          FirebaseConstants.photoURL],
                                    );
                                  }))
                        ],
                      ),
                    ),
          floatingActionButton: groupDetailScreenConsumer.loader
              ? null
              : !(groupDetailScreenConsumer.enableButton)
                  ? null
                  : FloatingActionButton(
                      heroTag: null,
                      backgroundColor: AppColors.primaryColor,
                      onPressed: () async {
                        chatWithUserList
                            .add(FirebaseAuth.instance.currentUser!.uid);
                        groupDetailScreenConsumer.loading();
                        String? photoUrl =
                            groupDetailScreenConsumer.groupImage == null
                                ? null
                                : await appCommonProvider.uploadImageFile(
                                    context,
                                    groupDetailScreenConsumer
                                        .groupNameController.text
                                        .trim(),
                                    groupDetailScreenConsumer.groupImage!);

                        await groupDetailScreenConsumer.createGroup(
                            groupdescription: groupDetailScreenConsumer
                                .groupdescriptionController.text
                                .trim(),
                            users: chatWithUserList,
                            groupImageUrl: photoUrl ?? '',
                            groupName: groupDetailScreenConsumer
                                .groupNameController.text
                                .trim());
                        groupDetailScreenConsumer.loading();
                        Navigator.pushReplacementNamed(
                            context, GenratedRoutes.chatDetailScreen,
                            arguments: {
                              AppStrings.searchedData: {
                                FirebaseConstants.chatRoomId:
                                    groupDetailScreenConsumer.groupId,
                                FirebaseConstants.userPath: chatWithUserList,
                                FirebaseConstants.photoURL: photoUrl,
                                FirebaseConstants.userName:
                                    groupDetailScreenConsumer
                                        .groupNameController.text
                                        .trim()
                              },
                              AppStrings.searchedScreen: false
                            });
                      },
                      child: const Icon(Icons.done),
                    ),
        );
      },
    );
  }
}
