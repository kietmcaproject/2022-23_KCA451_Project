// ignore_for_file: use_build_context_synchronously

import 'package:chat_app/app_shared_prefreneces/local_data.dart';

import 'package:chat_app/model/user_post_model.dart';
import 'package:chat_app/providers/add_post_screen_provider.dart';
import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/utlis/app_constants/app_constants.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_common_appbar.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:chat_app/utlis/widgets/app_elevated_button.dart';
import 'package:chat_app/utlis/widgets/app_netowrk_error.dart';
import 'package:chat_app/utlis/widgets/common_text_form_field.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddPostScreen extends StatefulWidget {
  const AddPostScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<AddPostScreen> createState() => _AddPostScreenState();
}

class _AddPostScreenState extends State<AddPostScreen> {
  @override
  Widget build(BuildContext context) {
    AppCommonProvider appCommonProvider =
        Provider.of<AppCommonProvider>(context, listen: true);
    // appCommonProvider.checkingConnection();
    double height = MediaQuery.of(context).size.height;
    return AppCommonAppBar(
        text: AppStrings.addPost,
        body: appCommonProvider.connectivity
            ? const AppNetworkErrorWidget()
            : Consumer<AddPostScreenProvider>(
                builder: (context, addPostScreenConsumer, child) {
                  return Form(
                    key: addPostScreenConsumer.postFormKey,
                    onChanged: addPostScreenConsumer.onTextFieldChanged,
                    child: ListView(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 20),
                      children: [
                        addPostScreenConsumer.imageFile == null
                            ? GestureDetector(
                                onTap: () async {
                                  addPostScreenConsumer.getImage(
                                      await appCommonProvider
                                          .imagePicking(context));
                                },
                                child: Container(
                                    padding: const EdgeInsets.all(28),
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                        color: AppColors.primaryColor
                                            .withOpacity(0.6),
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                            color: AppColors.grey800)),
                                    child:
                                        const Icon(Icons.camera_alt_rounded)),
                              )
                            : Container(
                                padding: const EdgeInsets.all(40),
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                        image: FileImage(
                                            addPostScreenConsumer.imageFile!),
                                        fit: BoxFit.fill),
                                    color:
                                        AppColors.primaryColor.withOpacity(0.6),
                                    shape: BoxShape.circle,
                                    border:
                                        Border.all(color: AppColors.grey800)),
                              ),
                        SizedBox(height: height * 0.05),
                        CommonTextFormField(
                            labelText: AppStrings.addLocation,
                            obscure: false,
                            controller:
                                addPostScreenConsumer.locationController,
                            keyboardType: TextInputType.multiline,
                            textInputAction: TextInputAction.newline),
                        SizedBox(height: height * 0.02),
                        SizedBox(
                          height: height * 0.09,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: AppConstants.locationData.length,
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: () {
                                  addPostScreenConsumer.locationController
                                      .text = AppConstants.locationData[index];
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(10),
                                  alignment: Alignment.center,
                                  margin: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      border:
                                          Border.all(color: AppColors.grey800),
                                      gradient: AppColors.enableGradient),
                                  child: Text(
                                    AppConstants.locationData[index],
                                    style: CommonTextStyles.white18w500
                                        .copyWith(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w400),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        SizedBox(height: height * 0.03),
                        CommonTextFormField(
                            labelText: AppStrings.caption,
                            obscure: false,
                            controller: addPostScreenConsumer.postController,
                            keyboardType: TextInputType.multiline,
                            textInputAction: TextInputAction.newline),
                        SizedBox(height: height * 0.08),
                        AppElevatedButton(
                          loader: addPostScreenConsumer.loader,
                          enableButton: addPostScreenConsumer.enableButton,
                          text: AppStrings.post,
                          onPressed: !addPostScreenConsumer.enableButton
                              ? null
                              : () async {
                                  addPostScreenConsumer.imageLoaderTrue();

                                  try {
                                    String? images =
                                        await appCommonProvider.uploadImageFile(
                                            context,
                                            AppSharedPrefrence().id!,
                                            addPostScreenConsumer.imageFile!);

                                    UserPostModel userPostData = UserPostModel(
                                        userId: AppSharedPrefrence().id,
                                        time: FieldValue.serverTimestamp(),
                                        postImage: [images],
                                        location: addPostScreenConsumer
                                            .locationController.text
                                            .trim(),
                                        message: addPostScreenConsumer
                                            .postController.text
                                            .trim());
                                    await appCommonProvider
                                        .addPost(userPostData);
                                    addPostScreenConsumer.imageLoaderFalse();
                                    Navigator.pushReplacementNamed(
                                        context, GenratedRoutes.homseScreen);
                                  } catch (e) {
                                    AppCommonSnackBar().appCommonSnackbar(
                                        context, AppStrings.errorToUploadPost);
                                    addPostScreenConsumer.imageLoaderFalse();
                                  }
                                },
                        )
                      ],
                    ),
                  );
                },
              ));
  }
}
