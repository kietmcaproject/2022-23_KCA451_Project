import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/providers/chat_detail_screen_provider.dart';
import 'package:chat_app/utlis/app_constants/app_constants.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_common_cached_network_image.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:chat_app/utlis/widgets/app_netowrk_error.dart';
import 'package:chat_app/utlis/widgets/common_text_form_field.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ChatDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> msgUser;
  final bool searchScreen;
  const ChatDetailsScreen(
      {Key? key, required this.msgUser, this.searchScreen = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    ChatDetailScreenProvider chatDetailScreenProvider =
        Provider.of(context, listen: false);
    AppCommonProvider appCommonProvider = Provider.of(context, listen: true);

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
              // searchScreen ? Navigator.pop(context) : null;
            }),
        backgroundColor: AppColors.primaryColor,
        title: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance
              .collection(FirebaseConstants.chatRoompath)
              .doc(msgUser[FirebaseConstants.chatRoomId])
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(
                  color: AppColors.white,
                ),
              );
            } else {
              if (!snapshot.hasData) {
                return const Center(child: Text(AppStrings.serverError));
              } else {
                Map<String, dynamic>? chatRoomData;

                if (snapshot.data!.data() == null ||
                    snapshot.data!.data()!.isEmpty) {
                  chatRoomData = msgUser;
                } else {
                  chatRoomData = snapshot.data!.data() as Map<String, dynamic>;
                }

                Map<String, dynamic>? groupData;

                if (chatRoomData[FirebaseConstants.isGroup] == null ||
                    chatRoomData[FirebaseConstants.isGroup] == false) {
                  try {
                    if (chatRoomData[FirebaseConstants.userPath] == null ||
                        chatRoomData[FirebaseConstants.userPath].isEmpty) {
                      groupData = appCommonProvider.allUsers?.firstWhere(
                          (element) =>
                              element![FirebaseConstants.id] ==
                              (chatRoomData![FirebaseConstants.id]));
                    } else {
                      (chatRoomData[FirebaseConstants.userPath] as List)
                          .cast<String>()
                          .remove(AppSharedPrefrence().id);
                      groupData = appCommonProvider.allUsers?.firstWhere(
                          (element) =>
                              element![FirebaseConstants.id] ==
                              (chatRoomData![FirebaseConstants.userPath]
                                      as List)
                                  .cast<String>()
                                  .first);
                    }
                  } on StateError {
                    const Center(
                        child: CircularProgressIndicator(
                      color: AppColors.primaryColor,
                    ));
                  }
                } else {
                  groupData = chatRoomData;
                }
                return GestureDetector(
                  onTap: () {
                    // add stream here
                    (groupData?[FirebaseConstants.isGroup] == null ||
                            groupData?[FirebaseConstants.isGroup] == false)
                        ? Navigator.pushNamed(context,
                            GenratedRoutes.userProfileScreen, arguments: {
                            FirebaseConstants.id:
                                groupData?[FirebaseConstants.id],
                            FirebaseConstants.descriptions:
                                groupData?[FirebaseConstants.descriptions],
                            FirebaseConstants.userName:
                                groupData?[FirebaseConstants.userName],
                            FirebaseConstants.phoneNumber:
                                groupData?[FirebaseConstants.phoneNumber],
                            FirebaseConstants.photoURL:
                                groupData?[FirebaseConstants.photoURL] ?? '',
                            FirebaseConstants.currentUser: false
                          })
                        : Navigator.pushNamed(
                            context, GenratedRoutes.groupDetailScreen,
                            arguments: msgUser[FirebaseConstants.chatRoomId]);
                  },
                  child: Row(
                    children: <Widget>[
                      SizedBox(
                          width: 40,
                          height: 40,
                          child: AppCommonCachedNetworkImage(
                            isGroup:
                                groupData?[FirebaseConstants.isGroup] ?? false,
                            errorIconSize: 0,
                            imageSize: 0,
                            imageUrl:
                                groupData?[FirebaseConstants.photoURL] ?? '',
                            post: false,
                          )),
                      const SizedBox(width: 10),
                      Text(
                        groupData?[FirebaseConstants.groupName] ??
                            groupData?[FirebaseConstants.userName],
                        style: CommonTextStyles.primaryTextStyle,
                      )
                    ],
                  ),
                );
              }
            }
          },
        ),
      ),
      body: appCommonProvider.connectivity
          ? const AppNetworkErrorWidget()
          : Consumer<ChatDetailScreenProvider>(
              builder: (context, chatDetailConsumer, child) => Container(
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    Expanded(
                      child: StreamBuilder<QuerySnapshot>(
                        stream: chatDetailScreenProvider.getMessages(
                            msgUser[FirebaseConstants.chatRoomId] ??
                                chatDetailConsumer.groupId),
                        builder: (context, snapshot) {
                          if (snapshot.hasError) {
                            return Text(snapshot.error.toString());
                          } else {
                            if (snapshot.hasData) {
                              if (snapshot.data!.docs.isEmpty) {
                                return const Center(
                                    child: Text(AppStrings.sayHi));
                              } else {
                                return ListView.builder(
                                  reverse: true,
                                  itemCount: snapshot.data!.docs.length,
                                  shrinkWrap: true,
                                  // physics: ClampingScrollPhysics(),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    Map<String, dynamic>? messages;
                                    try {
                                      messages = snapshot.data!.docs[index]
                                          .data() as Map<String, dynamic>;
                                    } catch (e) {
                                      print(e);
                                    }
                                    // print(msgUser);
                                    Map<String, dynamic>? messageBy =
                                        (msgUser[FirebaseConstants.isGroup] == null ||
                                                msgUser[FirebaseConstants.isGroup] ==
                                                    false)
                                            ? {}
                                            : (messages?[FirebaseConstants.sendby] ==
                                                    AppSharedPrefrence().id
                                                ? {}
                                                : Provider.of<AppCommonProvider>(
                                                        context,
                                                        listen: false)
                                                    .allUsers
                                                    ?.firstWhere((element) =>
                                                        element![FirebaseConstants.id] ==
                                                        messages![FirebaseConstants
                                                            .sendby]));

                                    return Column(
                                      children: [
                                        Text(messages?[FirebaseConstants
                                                    .sendTime] ==
                                                null
                                            ? ''
                                            : AppConstants.chatday(messages?[
                                                FirebaseConstants.sendTime])),
                                        Bubble(
                                          user: messageBy?[
                                              FirebaseConstants.userName],
                                          isMe: chatDetailScreenProvider.isME(
                                              messages?[
                                                  FirebaseConstants.sendby]),
                                          time: messages?[FirebaseConstants
                                                      .sendTime] ==
                                                  null
                                              ? null
                                              : chatDetailScreenProvider
                                                  .chatTime(messages?[
                                                      FirebaseConstants
                                                          .sendTime])!,
                                          message: messages?[
                                              FirebaseConstants.message],
                                        ),
                                      ],
                                    );
                                  },
                                );
                              }
                            } else {
                              return const Center(
                                child: CircularProgressIndicator(
                                  color: AppColors.primaryColor,
                                ),
                              );
                            }
                          }
                        },
                      ),
                    ),
                    Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.shade300,
                              offset: const Offset(-2, 0),
                              blurRadius: 5,
                            ),
                          ],
                        ),
                        child: CommonTextFormField(
                            labelText: '',
                            controller:
                                chatDetailScreenProvider.chatTextController,
                            textInputAction: TextInputAction.newline,
                            keyboardType: TextInputType.multiline,
                            suffixIcon: true,
                            obscure: false,
                            suffixIconWidget: IconButton(
                              icon: const Icon(
                                Icons.send,
                                color: AppColors.primaryColor,
                              ),
                              onPressed: () {
                                (!(chatDetailConsumer.chatTextController.text
                                                .trim() ==
                                            '' ||
                                        chatDetailConsumer
                                            .chatTextController.text.isEmpty))
                                    ? chatDetailScreenProvider.addChatUser(
                                        listOfMembers: (msgUser[
                                                        FirebaseConstants
                                                            .userPath] ==
                                                    null ||
                                                msgUser[FirebaseConstants
                                                        .userPath]
                                                    .isEmpty)
                                            ? null
                                            : (msgUser[FirebaseConstants
                                                    .userPath] as List)
                                                .cast<String>(),
                                        context: context,
                                        chatRoomId: msgUser[
                                            FirebaseConstants.chatRoomId],
                                        chatWithUser:
                                            msgUser[FirebaseConstants.id],
                                      )
                                    : AppCommonSnackBar().appCommonSnackbar(
                                        context, AppStrings.addSometext);
                              },
                            ))),
                  ],
                ),
              ),
            ),
    );
  }
}

class Bubble extends StatelessWidget {
  final bool isMe;
  final String message;
  final String? user;
  final String? time;

  const Bubble(
      {Key? key,
      required this.message,
      required this.isMe,
      required this.time,
      required this.user})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(5),
      padding: isMe
          ? const EdgeInsets.only(left: 40)
          : const EdgeInsets.only(right: 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Column(
            crossAxisAlignment:
                isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: isMe
                      ? AppColors.enableGradient
                      : AppColors.disableGradient,
                  borderRadius: isMe
                      ? const BorderRadius.only(
                          topRight: Radius.circular(15),
                          topLeft: Radius.circular(15),
                          bottomRight: Radius.circular(0),
                          bottomLeft: Radius.circular(15),
                        )
                      : const BorderRadius.only(
                          topRight: Radius.circular(15),
                          topLeft: Radius.circular(15),
                          bottomRight: Radius.circular(15),
                          bottomLeft: Radius.circular(0),
                        ),
                ),
                child: Column(
                  crossAxisAlignment:
                      isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                  children: <Widget>[
                    (user == null || user == '')
                        ? const SizedBox.shrink()
                        : Text(
                            user!,
                            style: CommonTextStyles.white18w500.copyWith(
                                fontSize: 16,
                                // fontWeight: FontWeight.w800,
                                color: AppColors.red),
                          ),
                    const SizedBox(
                      height: 5,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                          right: isMe ? 20 : 0, left: isMe ? 0 : 20),
                      child: Text(message,
                          textAlign: isMe ? TextAlign.end : TextAlign.start,
                          style: CommonTextStyles.white18w500
                              .copyWith(fontSize: 14)),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    (time == null || time == '' || time!.isEmpty)
                        ? const Icon(
                            Icons.watch_later_outlined,
                            color: AppColors.white,
                            size: 12,
                          )
                        : Text(
                            time!,
                            style: CommonTextStyles.white18w500
                                .copyWith(fontSize: 10),
                          ),
                  ],
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
