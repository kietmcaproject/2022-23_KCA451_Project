import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/providers/chat_screen_provider.dart';
import 'package:chat_app/utlis/app_constants/app_constants.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/widgets/app_netowrk_error.dart';
import 'package:chat_app/utlis/widgets/user_info_tile.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/common_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Consumer2<ChatScreenProvider, AppCommonProvider>(
        builder: (context, chatScreenConsumer, appCommonConsumer, child) {
      return Scaffold(
        appBar: AppBar(
          toolbarHeight: chatScreenConsumer.searching ? height * 0.2 : null,
          flexibleSpace: chatScreenConsumer.searching
              ? Container(
                  width: width * 0.7,
                  margin: EdgeInsets.only(
                      left: 10,
                      bottom: 10,
                      top: MediaQuery.of(context).padding.top + height * 0.07,
                      right: 10),
                  child: CommonTextFormField(
                    labelText: '',
                    obscure: false,
                    suffixIcon: true,
                    suffixIconWidget: IconButton(
                        onPressed: chatScreenConsumer.searchCnacel,
                        icon: const Icon(
                          Icons.close,
                          color: AppColors.black,
                        )),
                    onChanged: (String text) {
                      chatScreenConsumer.searchStart();
                    },
                    controller: chatScreenConsumer.messageSearchController,
                    textInputAction: TextInputAction.done,
                  ),
                )
              : null,
          leading: chatScreenConsumer.searching
              ? const SizedBox.shrink()
              : IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () => Navigator.pop(context),
                ),
          // leadingWidth: 0,
          backgroundColor: chatScreenConsumer.searching
              ? AppColors.white
              : AppColors.primaryColor,
          title: chatScreenConsumer.searching
              ? null
              : Text(
                  AppStrings.messages,
                  style: CommonTextStyles.primaryTextStyle,
                ),
          actions: chatScreenConsumer.searching
              ? []
              : [
                  IconButton(
                      onPressed: chatScreenConsumer.searchStart,
                      icon: const Icon(Icons.search))
                ],
        ),
        body: appCommonConsumer.connectivity
            ? const AppNetworkErrorWidget()
            : StreamBuilder<List<Map<String, dynamic>?>?>(
                stream: chatScreenConsumer.getUSerDetail(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(
                        color: AppColors.primaryColor,
                      ),
                    );
                  } else {
                    if (!snapshot.hasData) {
                      return Center(
                          child: Text(AppStrings.addSomeUser,
                              style: CommonTextStyles.white18w500.copyWith(
                                color: AppColors.grey800,
                              )));
                    } else {
                      if (snapshot.data!.isNotEmpty) {
                        if (snapshot.hasError) {
                          return const Center(
                              child: Text(AppStrings.serverError));
                        } else {
                          chatScreenConsumer.getChatWithUser(snapshot.data!);
                          return chatScreenConsumer.searching
                              ? (chatScreenConsumer.searchedData.isEmpty)
                                  ? const Center(
                                      child: Text(AppStrings.noUSerFound))
                                  : ListView.builder(
                                      padding: const EdgeInsets.all(10),
                                      itemCount: chatScreenConsumer
                                          .searchedData.length,
                                      itemBuilder: (context, ind) {
                                        return UserInfoTile(
                                          subTitle: chatScreenConsumer
                                                      .searchedData[ind][
                                                  FirebaseConstants
                                                      .descriptions] ??
                                              '',
                                          onTap: () {
                                            Navigator.pushNamed(context,
                                                GenratedRoutes.chatDetailScreen,
                                                arguments: {
                                                  AppStrings.searchedData:
                                                      chatScreenConsumer
                                                          .searchedData[ind],
                                                  AppStrings.searchedScreen:
                                                      true
                                                });
                                          },
                                          username: chatScreenConsumer
                                                  .searchedData[ind]
                                              [FirebaseConstants.userName],
                                          userImage: chatScreenConsumer
                                                  .searchedData[ind]
                                              [FirebaseConstants.photoURL],
                                        );
                                      })
                              : ListView.builder(
                                  itemCount: snapshot.data!.length,
                                  shrinkWrap: true,
                                  itemBuilder: (context, index) {
                                    Map<String, dynamic>? chatUsers =
                                        snapshot.data![index];

                                    appCommonConsumer.allUsers!.removeWhere(
                                        (value) =>
                                            value![FirebaseConstants.id] ==
                                            chatUsers?[FirebaseConstants.id]);

                                    appCommonConsumer.allUsers!.add(chatUsers);

                                    return UserInfoTile(
                                      isGroup: chatUsers?[
                                              FirebaseConstants.isGroup] ??
                                          false,
                                      onTap: () => Navigator.pushNamed(context,
                                          GenratedRoutes.chatDetailScreen,
                                          arguments: {
                                            AppStrings.searchedData: chatUsers,
                                            AppStrings.searchedScreen: false
                                          }),
                                      subTitle: chatUsers![
                                              FirebaseConstants.lastMessage] ??
                                          (chatUsers[FirebaseConstants
                                                  .descriptions] ??
                                              ''),
                                      time: chatUsers[
                                                  FirebaseConstants.sendTime] ==
                                              null
                                          ? ''
                                          : AppConstants.intractWhen(chatUsers[
                                              FirebaseConstants.sendTime]),
                                      username: chatUsers[
                                              FirebaseConstants.userName] ??
                                          '',
                                      userImage:
                                          chatUsers[FirebaseConstants.photoURL],
                                      newMessage: index % 2 == 0 ? true : false,
                                      sendBy: chatScreenConsumer.lastSender(
                                          isGroup: chatUsers[
                                              FirebaseConstants.isGroup],
                                          allUsers: appCommonConsumer.allUsers,
                                          id: chatUsers[
                                                  FirebaseConstants.sendby] ??
                                              ''),
                                    );
                                  },
                                );
                        }
                      } else {
                        return Center(
                            child: Text(AppStrings.addSomeUser,
                                style: CommonTextStyles.white18w500.copyWith(
                                  color: AppColors.grey800,
                                )));
                      }
                    }
                  }
                }),
        floatingActionButton: FloatingActionButton(
          backgroundColor: AppColors.primaryColor,
          onPressed: () =>
              Navigator.pushNamed(context, GenratedRoutes.searchScreen),
          child: const Icon(
            Icons.add,
            color: AppColors.white,
          ),
        ),
      );
    });
  }
}
