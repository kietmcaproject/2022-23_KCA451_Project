// ignore_for_file: use_build_context_synchronously

import 'package:chat_app/app_shared_prefreneces/local_data.dart';

import 'package:chat_app/providers/forgot_password_screen_provider.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/validator/email_validator.dart';
import 'package:chat_app/utlis/widgets/app_common_background.dart';
import 'package:chat_app/utlis/widgets/app_elevated_button.dart';
import 'package:chat_app/utlis/widgets/common_text_form_field.dart';
import 'package:chat_app/utlis/widgets/gradient_text.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    ForgotPasswordScreenProvider forgotPasswordScreenProvider =
        Provider.of<ForgotPasswordScreenProvider>(context, listen: false);
    return AppCommonBackground(
        widget: Column(
      children: [
        GradientText(AppStrings.forgotPassword,
            style: CommonTextStyles.primaryTextStyle),
        SizedBox(
          height: height * 0.05,
        ),
        Form(
          key: forgotPasswordScreenProvider.forgotFormKey,
          onChanged: forgotPasswordScreenProvider.onChanged,
          child: CommonTextFormField(
            labelText: AppStrings.email,
            textInputAction: TextInputAction.next,
            keyboardType: TextInputType.emailAddress,
            validator: EmailValidator().validateEmail,
            controller: forgotPasswordScreenProvider.emailController,
            prefixIcon: Icon(
              Icons.email_sharp,
              size: 25,
              color: AppColors.grey800,
            ),
          ),
        ),
        SizedBox(
          height: height * 0.08,
        ),
        Consumer<ForgotPasswordScreenProvider>(
          builder: (context, forgotScreenConsumer, child) => AppElevatedButton(
            text: AppStrings.submit,
            enableButton: forgotScreenConsumer.enableButton,
            loader: forgotScreenConsumer.buttonLoader,
            onPressed: forgotScreenConsumer.enableButton
                ? () async {
                    if (forgotScreenConsumer.forgotFormKey.currentState!
                        .validate()) {
                      await forgotScreenConsumer.resetPassword(
                          context: context);
                      AppSharedPrefrence().getCurrentUser();
                    }
                  }
                : null,
          ),
        ),
      ],
    ));
  }
}
