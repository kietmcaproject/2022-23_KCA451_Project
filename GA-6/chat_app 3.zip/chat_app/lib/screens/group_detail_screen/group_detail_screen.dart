import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/providers/group_detail_screen_provider.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/common_methods.dart/common_methods.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_common_appbar.dart';
import 'package:chat_app/utlis/widgets/app_common_cached_network_image.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:chat_app/utlis/widgets/app_text_button.dart';
import 'package:chat_app/utlis/widgets/common_text_form_field.dart';
import 'package:chat_app/utlis/widgets/user_info_tile.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class GroupDetailScreen extends StatelessWidget {
  final String chatRoomId;
  const GroupDetailScreen({Key? key, required this.chatRoomId})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double width = MediaQuery.of(context).size.width;
    final double height = MediaQuery.of(context).size.height;
    final GroupDeatilScreenProvider groupDeatilScreenProvider =
        Provider.of(context, listen: false);
    final AppCommonProvider appCommonProvider =
        Provider.of(context, listen: true);

    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection(FirebaseConstants.chatRoompath)
          .doc(chatRoomId)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(
              color: AppColors.primaryColor,
            ),
          );
        } else {
          if (!snapshot.hasData) {
            return const Center(
              child: Text(AppStrings.noGroupData),
            );
          } else {
            if (snapshot.data!.data()!.isEmpty) {
              return const Center(
                child: Text(AppStrings.noGroupData),
              );
            } else {
              Map<String, dynamic>? streamGroupData = snapshot.data!.data();

              groupDeatilScreenProvider.onInit(
                  adminList:
                      (streamGroupData?[FirebaseConstants.groupAdmin] as List)
                          .cast<String>(),
                  groupName: streamGroupData?[FirebaseConstants.userName],
                  groupdescription:
                      streamGroupData?[FirebaseConstants.descriptions] ?? '');
              return AppCommonAppBar(
                text: AppStrings.groupDetails,
                appBarAction: [
                  (IconButton(
                      icon: const Icon(
                        Icons.exit_to_app,
                        color: AppColors.red,
                      ),
                      onPressed: () async {
                        if ((streamGroupData?[FirebaseConstants.groupAdmin]
                                    as List)
                                .cast<String>()
                                .contains(AppSharedPrefrence().id) &&
                            (streamGroupData?[FirebaseConstants.groupAdmin]
                                        as List)
                                    .cast<String>()
                                    .length ==
                                1) {
                          AppCommonSnackBar().appCommonSnackbar(
                              context, AppStrings.makeSomeAdminThenExitGroup);
                        } else {
                          CommonMethods().appShowDialoge(
                              context: context,
                              yesOnPressed: () async {
                                Navigator.pop(context);
                                (streamGroupData?[FirebaseConstants.userPath]
                                        as List)
                                    .cast<String>()
                                    .remove(AppSharedPrefrence().id);

                                (streamGroupData?[FirebaseConstants.groupAdmin]
                                        as List)
                                    .cast<String>()
                                    .remove(AppSharedPrefrence().id);
                                await groupDeatilScreenProvider.exitFromGroup(
                                    context: context,
                                    groupId: chatRoomId,
                                    data: {
                                      FirebaseConstants.userPath:
                                          (streamGroupData?[FirebaseConstants
                                                  .userPath] as List)
                                              .cast<String>(),
                                      FirebaseConstants.groupAdmin:
                                          (streamGroupData?[FirebaseConstants
                                                  .groupAdmin] as List)
                                              .cast<String>()
                                    });
                              },
                              message: AppStrings.exitGroup);
                        }
                      }))
                ],
                body: Consumer<GroupDeatilScreenProvider>(
                  builder: (context, groupDeatilScreenConsumer, child) =>
                      ListView(
                    padding: const EdgeInsets.all(10),
                    children: [
                      Stack(
                        children: [
                          groupDeatilScreenConsumer.image == null
                              ? Center(
                                  child: AppCommonCachedNetworkImage(
                                      imageUrl: streamGroupData?[
                                          FirebaseConstants.photoURL],
                                      imageSize: width * 0.15,
                                      post: false,
                                      isGroup: true,
                                      errorIconSize: width * 0.15),
                                )
                              : Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 8),
                                  child: CircleAvatar(
                                    radius: width * 0.15,
                                    foregroundImage: FileImage(
                                        groupDeatilScreenConsumer.image!),
                                  ),
                                ),
                          groupDeatilScreenProvider.isAdmin
                              ? Positioned(
                                  right: groupDeatilScreenConsumer.image == null
                                      ? width * 0.3
                                      : width * 0.00,
                                  top: height * 0,
                                  child: groupDeatilScreenConsumer.editablePhoto
                                      ? IconButton(
                                          onPressed: () async {
                                            groupDeatilScreenProvider
                                                .imageGetter(await Provider.of<
                                                            AppCommonProvider>(
                                                        context,
                                                        listen: false)
                                                    .imagePicking(context));
                                          },
                                          icon: Icon(
                                            Icons.camera_enhance,
                                            color: AppColors.black,
                                            size: width * 0.1,
                                          ))
                                      : IconButton(
                                          onPressed: () {
                                            groupDeatilScreenConsumer
                                                .editPhoto();
                                          },
                                          icon: Icon(
                                            Icons.edit,
                                            color: AppColors.black,
                                            size: width * 0.1,
                                          )),
                                )
                              : const SizedBox.shrink()
                        ],
                      ),
                      groupDeatilScreenConsumer.image != null
                          ? ApptextButton(
                              text: AppStrings.uploadImage,
                              fontSize: 16,
                              onPressed: () async {
                                if (groupDeatilScreenProvider.image == null) {
                                  AppCommonSnackBar().appCommonSnackbar(
                                      context, AppStrings.firstSelectImage);
                                } else {
                                  await groupDeatilScreenProvider.updateGroupImage(
                                      imaegUrl: (await Provider.of<
                                                  AppCommonProvider>(context,
                                              listen: false)
                                          .uploadImageFile(
                                              context,
                                              '${FirebaseConstants.groupImages}/$chatRoomId',
                                              groupDeatilScreenProvider
                                                  .image!))!,
                                      chatRoomId: chatRoomId,
                                      context: context);
                                }
                              },
                            )
                          : const SizedBox.shrink(),
                      SizedBox(
                        height: groupDeatilScreenConsumer.editablePhoto
                            ? 0
                            : height * 0.04,
                      ),
                      CommonTextFormField(
                          labelText: AppStrings.groupName,
                          suffixIcon: groupDeatilScreenProvider.isAdmin,
                          obscure: false,
                          suffixIconWidget:
                              groupDeatilScreenConsumer.editiableGroupName
                                  ? IconButton(
                                      icon: Icon(
                                        Icons.done,
                                        color: AppColors.grey800,
                                      ),
                                      onPressed:
                                          (groupDeatilScreenConsumer
                                                      .groupNameController
                                                      .text
                                                      .isEmpty ||
                                                  groupDeatilScreenConsumer
                                                          .groupNameController
                                                          .text ==
                                                      '')
                                              ? null
                                              : () async {
                                                  groupDeatilScreenConsumer
                                                      .editGroupName();
                                                  await groupDeatilScreenProvider.updateGroupNameOrdescription(
                                                      members: streamGroupData?[
                                                                  FirebaseConstants
                                                                      .userPath] ==
                                                              null
                                                          ? null
                                                          : (streamGroupData?[
                                                                      FirebaseConstants
                                                                          .userPath]
                                                                  as List)
                                                              .cast<String>(),
                                                      data: groupDeatilScreenProvider
                                                          .groupNameController
                                                          .text
                                                          .trim(),
                                                      chatRoomId: chatRoomId,
                                                      field: FirebaseConstants
                                                          .userName,
                                                      context: context);
                                                },
                                    )
                                  : IconButton(
                                      icon: Icon(
                                        Icons.edit,
                                        color: AppColors.grey800,
                                      ),
                                      onPressed: () {
                                        groupDeatilScreenConsumer
                                            .editGroupName();
                                      },
                                    ),
                          readOnly:
                              !groupDeatilScreenConsumer.editiableGroupName,
                          controller:
                              groupDeatilScreenProvider.groupNameController,
                          textInputAction: TextInputAction.done),
                      SizedBox(height: height * 0.02),
                      Consumer<GroupDeatilScreenProvider>(
                        builder: (context, groupDeatilScreenConsumer, child) =>
                            CommonTextFormField(
                                labelText: AppStrings.description,
                                keyboardType: TextInputType.multiline,
                                suffixIcon: groupDeatilScreenProvider.isAdmin,
                                obscure: false,
                                suffixIconWidget: groupDeatilScreenConsumer
                                        .editiableGroupdescription
                                    ? IconButton(
                                        icon: Icon(
                                          Icons.done,
                                          color: AppColors.grey800,
                                        ),
                                        onPressed: () async {
                                          groupDeatilScreenConsumer
                                              .editGroupdescription();
                                          await groupDeatilScreenProvider
                                              .updateGroupNameOrdescription(
                                                  data: groupDeatilScreenProvider
                                                      .groupdescriptionController
                                                      .text
                                                      .trim(),
                                                  chatRoomId: chatRoomId,
                                                  field: FirebaseConstants
                                                      .descriptions,
                                                  context: context);
                                        },
                                      )
                                    : IconButton(
                                        icon: Icon(
                                          Icons.edit,
                                          color: AppColors.grey800,
                                        ),
                                        onPressed: () {
                                          groupDeatilScreenConsumer
                                              .editGroupdescription();
                                        },
                                      ),
                                readOnly: !groupDeatilScreenConsumer
                                    .editiableGroupdescription,
                                controller: groupDeatilScreenProvider
                                    .groupdescriptionController,
                                textInputAction: TextInputAction.newline),
                      ),
                      SizedBox(height: height * 0.05),
                      Row(
                        children: [
                          Text(
                              '${AppStrings.participants}: ${(streamGroupData?[FirebaseConstants.userPath] as List).cast<String>().length}',
                              style: CommonTextStyles.white18w500.copyWith(
                                  color: AppColors.grey800,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400)),
                          const Spacer(),
                          groupDeatilScreenProvider.isAdmin
                              ? ApptextButton(
                                  onPressed: () {
                                    Navigator.pushNamed(
                                        context, GenratedRoutes.newGroupScreen,
                                        arguments: {
                                          AppStrings.searchedScreen: false,
                                          AppStrings.groupMembers:
                                              streamGroupData?[
                                                  FirebaseConstants.userPath],
                                          FirebaseConstants.chatRoomId:
                                              chatRoomId
                                        });
                                  },
                                  text: AppStrings.addMembers,
                                  fontSize: 16,
                                )
                              : const SizedBox.shrink(),
                        ],
                      ),
                      SizedBox(
                        height: height * 0.02,
                      ),
                      SizedBox(
                          child: ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount:
                            streamGroupData?[FirebaseConstants.userPath].length,
                        itemBuilder: (context, index) {
                          Map<String, dynamic>? groupMember;

                          if (streamGroupData?[FirebaseConstants.userPath]
                                  [index] ==
                              AppSharedPrefrence().id) {
                            groupMember = {
                              FirebaseConstants.id: AppSharedPrefrence().id,
                              FirebaseConstants.photoURL:
                                  AppSharedPrefrence().userProfile,
                              FirebaseConstants.userName:
                                  AppSharedPrefrence().username,
                              FirebaseConstants.phoneNumber:
                                  AppSharedPrefrence().phoneNo,
                              FirebaseConstants.descriptions:
                                  AppSharedPrefrence().description,
                            };
                          } else {
                            groupMember = appCommonProvider.allUsers!
                                .firstWhere((usersData) =>
                                    usersData![FirebaseConstants.id] ==
                                    streamGroupData?[FirebaseConstants.userPath]
                                        [index]);
                          }

                          return Consumer<GroupDeatilScreenProvider>(
                            builder:
                                (context, groupDeatilScreenConsumer, child) =>
                                    UserInfoTile(
                                        onLongPress: () {
                                          showDialog(
                                              context: context,
                                              builder:
                                                  (contex) =>
                                                      CupertinoAlertDialog(
                                                        actions: [
                                                          ApptextButton(
                                                              fontSize: 16,
                                                              text: AppStrings
                                                                  .info,
                                                              onPressed: () {
                                                                Navigator.of(
                                                                        context)
                                                                    .pop();
                                                                _navigate(
                                                                    context,
                                                                    groupMember);
                                                              }),
                                                          groupDeatilScreenProvider
                                                                  .isAdmin
                                                              // checking admins in list
                                                              ? (groupMember?[FirebaseConstants
                                                                          .id] ==
                                                                      AppSharedPrefrence()
                                                                          .id
                                                                  // checing current user is admin or not
                                                                  ? const SizedBox
                                                                      .shrink()
                                                                  : (

                                                                      // checking for adding or removing from admin list
                                                                      !streamGroupData?[FirebaseConstants.groupAdmin].contains(groupMember![FirebaseConstants
                                                                              .id])
                                                                          ?
                                                                          // adding to admin if you are admin
                                                                          ApptextButton(
                                                                              fontSize: 16,
                                                                              text: AppStrings.makeAdmin,
                                                                              onPressed: () async {
                                                                                (streamGroupData?[FirebaseConstants.groupAdmin] as List).cast<String>().add(groupMember![FirebaseConstants.id]);
                                                                                Navigator.of(context).pop();
                                                                                await groupDeatilScreenProvider.addAdmin(adminList: (streamGroupData?[FirebaseConstants.groupAdmin] as List).cast<String>(), chatRoomId: chatRoomId, context: context);
                                                                              },
                                                                            )
                                                                          // remove from admin
                                                                          : ApptextButton(
                                                                              fontSize: 16,
                                                                              text: AppStrings.removeAdmin,
                                                                              onPressed: () async {
                                                                                (streamGroupData?[FirebaseConstants.groupAdmin] as List).cast<String>().remove(groupMember![FirebaseConstants.id]);
                                                                                Navigator.of(context).pop();
                                                                                await groupDeatilScreenProvider.removeAdmin(adminList: (streamGroupData?[FirebaseConstants.groupAdmin] as List).cast<String>(), chatRoomId: chatRoomId, context: context);
                                                                              },
                                                                            )))
                                                              : const SizedBox
                                                                  .shrink(),
                                                          groupDeatilScreenProvider
                                                                  .isAdmin
                                                              ? (groupMember?[FirebaseConstants
                                                                          .id] ==
                                                                      AppSharedPrefrence()
                                                                          .id
                                                                  ? ApptextButton(
                                                                      fontSize:
                                                                          16,
                                                                      onPressed:
                                                                          () {
                                                                        //TODO.. Delete group
                                                                      },
                                                                      text: AppStrings
                                                                          .exitGroup,
                                                                      textColor:
                                                                          AppColors
                                                                              .red,
                                                                    )
                                                                  : ApptextButton(
                                                                      fontSize:
                                                                          16,
                                                                      onPressed:
                                                                          () async {
                                                                        (streamGroupData?[FirebaseConstants.userPath]
                                                                                as List)
                                                                            .cast<String>()
                                                                            .remove(groupMember?[FirebaseConstants.id]);

                                                                        Navigator.pop(
                                                                            context);

                                                                        await groupDeatilScreenProvider.removeUserFromGroup(
                                                                            context:
                                                                                context,
                                                                            groupId:
                                                                                chatRoomId,
                                                                            userId:
                                                                                groupMember![FirebaseConstants.id],
                                                                            data: {
                                                                              FirebaseConstants.userPath: (streamGroupData?[FirebaseConstants.userPath] as List).cast<String>(),
                                                                            });
                                                                      },
                                                                      text: AppStrings
                                                                          .remove,
                                                                      textColor:
                                                                          AppColors
                                                                              .red,
                                                                    ))
                                                              : const SizedBox
                                                                  .shrink()
                                                        ],
                                                      ));
                                        },
                                        onTap: () {
                                          _navigate(
                                            context,
                                            groupMember,
                                          );
                                        },
                                        admin: groupDeatilScreenProvider
                                            .checkingAdmin(
                                                (streamGroupData?[FirebaseConstants
                                                        .groupAdmin] as List)
                                                    .cast<String>(),
                                                streamGroupData?[
                                                    FirebaseConstants
                                                        .userPath][index]),
                                        userImage: groupMember![
                                            FirebaseConstants.photoURL],
                                        username: groupMember[
                                            FirebaseConstants.userName],
                                        subTitle: groupMember[FirebaseConstants
                                                .descriptions] ??
                                            ''),
                          );
                        },
                      ))
                    ],
                  ),
                ),
              );
            }
          }
        }
      },
    );
  }

  void _navigate(
    BuildContext context,
    Map<String, dynamic>? groupMember,
  ) {
    Navigator.pushNamed(context, GenratedRoutes.userProfileScreen, arguments: {
      FirebaseConstants.id: groupMember?[FirebaseConstants.id],
      FirebaseConstants.descriptions:
          groupMember?[FirebaseConstants.descriptions],
      FirebaseConstants.userName: groupMember?[FirebaseConstants.userName],
      FirebaseConstants.phoneNumber:
          groupMember?[FirebaseConstants.phoneNumber],
      FirebaseConstants.photoURL: groupMember?[FirebaseConstants.photoURL],
      FirebaseConstants.currentUser:
          groupMember?[FirebaseConstants.id] == AppSharedPrefrence().id
              ? true
              : false,
    });
  }
}
