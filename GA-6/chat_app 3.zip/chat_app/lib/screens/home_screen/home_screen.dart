import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/providers/home_screen_provider.dart';
import 'package:chat_app/screens/home_screen/user_name_with_image_widget.dart';
import 'package:chat_app/utlis/app_constants/app_constants.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_images.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/common_methods.dart/common_methods.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_common_appbar.dart';
import 'package:chat_app/utlis/widgets/app_common_cached_network_image.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:chat_app/utlis/widgets/app_netowrk_error.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({Key? key}) : super(key: key);
  final AppSharedPrefrence _localData = AppSharedPrefrence();
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    HomeScreenProvider homeScreenProvider = Provider.of(context, listen: false);
    AppCommonProvider appCommonProvider = Provider.of(context, listen: true);
    appCommonProvider.checkingConnection();

    return WillPopScope(
      onWillPop: () async {
        SystemNavigator.pop();
        return true;
      },
      child: AppCommonAppBar(
        floatCenter: true,
        appBarLeadingIcon: Consumer<HomeScreenProvider>(
          builder: (context, homeScreenConsumer, child) => IconButton(
            icon: Icon(homeScreenConsumer.openMenu ? Icons.close : Icons.menu),
            onPressed: homeScreenConsumer.menuBar,
          ),
        ),
        text: AppStrings.appName,
        appBarAction: [
          IconButton(
              onPressed: (() {
                Navigator.pushNamed(context, GenratedRoutes.chatScreen);
              }),
              icon: Image.asset(
                AppImages.messageIcon,
                color: AppColors.white,
              )),
        ],
        body: (appCommonProvider.connectivity)
            ? const AppNetworkErrorWidget()
            : ListView(
                children: [
                  SizedBox(
                      height: height * 0.15,
                      child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                        stream: homeScreenProvider.getStory(),
                        builder: (BuildContext context, snapshot) {
                          if (snapshot.hasError) {
                            AppCommonSnackBar().appCommonSnackbar(
                                context, AppStrings.serverError);
                            return const SizedBox.shrink();
                          } else {
                            if (!snapshot.hasData) {
                              return const Center(
                                  child: CircularProgressIndicator(
                                color: AppColors.primaryColor,
                              ));
                            } else {
                              appCommonProvider.getAllData(snapshot.data!.docs
                                  .map((e) => e.data())
                                  .toList());

                              return ListView(
                                scrollDirection: Axis.horizontal,
                                physics: const BouncingScrollPhysics(),
                                children: [
                                  UserNameWithImageWidget(
                                      iconWidget: const Icon(Icons.add),
                                      onTap: () {
                                        AppCommonSnackBar().appCommonSnackbar(
                                            context, AppStrings.underProcess);
                                        // Navigator.pushNamed(context,
                                        //     GenratedRoutes.addPostScreen);
                                      },
                                      storySeen: false,
                                      userName: AppStrings.yourStory,
                                      userProfile: _localData.userProfile),
                                  SizedBox(
                                    child: ListView.builder(
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      scrollDirection: Axis.horizontal,
                                      shrinkWrap: true,
                                      itemCount: (snapshot.data?.docs.length)!,
                                      itemBuilder: (context, index) {
                                        Map<String, dynamic> data =
                                            snapshot.data!.docs[index].data();

                                        return Consumer<HomeScreenProvider>(
                                          builder: (context, homeScreenConsumer,
                                                  child) =>
                                              UserNameWithImageWidget(
                                            onTap: (() {
                                              AppCommonSnackBar()
                                                  .appCommonSnackbar(context,
                                                      AppStrings.underProcess);
                                            }),
                                            storySeen: true,
                                            userName:
                                                data[FirebaseConstants.userName]
                                                    .toString(),
                                            userProfile: data[
                                                FirebaseConstants.photoURL],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              );
                            }
                          }
                        },
                      )),
                  StreamBuilder<List<Map<dynamic, dynamic>>>(
                      stream: homeScreenProvider.getpost(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          return const Center(
                            child: CircularProgressIndicator(
                                color: AppColors.primaryColor),
                          );
                        } else {
                          List<Map<dynamic, dynamic>> docs = snapshot.data!;

                          if (docs.isEmpty) {
                            return Padding(
                              padding: EdgeInsets.only(top: height * 0.3),
                              child: const Center(
                                  child: Text(AppStrings.addSomeStory)),
                            );
                          } else {
                            return SizedBox(
                              child: ListView.builder(
                                physics: const NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                itemCount: docs.length,
                                itemBuilder: (context, index) {
                                  Map<dynamic, dynamic> data = docs[index];

                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 10),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Row(children: [
                                          GestureDetector(
                                            onTap: (() {
                                              Navigator.pushNamed(
                                                  context,
                                                  GenratedRoutes
                                                      .userProfileScreen,
                                                  arguments: {
                                                    FirebaseConstants.id: data[
                                                        FirebaseConstants.id],
                                                    FirebaseConstants
                                                            .descriptions:
                                                        '${data[FirebaseConstants.descriptions]}',
                                                    FirebaseConstants.userName:
                                                        '${data[FirebaseConstants.userName]}',
                                                    FirebaseConstants
                                                            .phoneNumber:
                                                        '${data[FirebaseConstants.phoneNumber]}',
                                                    FirebaseConstants.photoURL:
                                                        data[FirebaseConstants
                                                                .photoURL] ??
                                                            '',
                                                    FirebaseConstants
                                                            .currentUser:
                                                        data[FirebaseConstants
                                                                    .id] ==
                                                                _localData.id
                                                            ? true
                                                            : false,
                                                  });
                                            }),
                                            child: Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 5,
                                                        vertical: 5),
                                                child:
                                                    AppCommonCachedNetworkImage(
                                                  errorIconSize: width * 0.07,
                                                  imageSize: width * 0.06,
                                                  imageUrl: data[
                                                      FirebaseConstants
                                                          .photoURL],
                                                  isGroup: false,
                                                  post: false,
                                                )),
                                          ),
                                          GestureDetector(
                                            onTap: (() {
                                              Navigator.pushNamed(
                                                  context,
                                                  GenratedRoutes
                                                      .userProfileScreen,
                                                  arguments: {
                                                    FirebaseConstants.id: data[
                                                        FirebaseConstants.id],
                                                    FirebaseConstants
                                                            .descriptions:
                                                        '${data[FirebaseConstants.descriptions]}',
                                                    FirebaseConstants.userName:
                                                        '${data[FirebaseConstants.userName]}',
                                                    FirebaseConstants
                                                            .phoneNumber:
                                                        '${data[FirebaseConstants.phoneNumber]}',
                                                    FirebaseConstants.photoURL:
                                                        data[FirebaseConstants
                                                                .photoURL] ??
                                                            '',
                                                    FirebaseConstants
                                                            .currentUser:
                                                        data[FirebaseConstants
                                                                    .id] ==
                                                                _localData.id
                                                            ? true
                                                            : false,
                                                  });
                                            }),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  '${data[FirebaseConstants.userName]}',
                                                  style: CommonTextStyles
                                                      .boldText
                                                      .copyWith(fontSize: 16),
                                                ),
                                                Text(
                                                  data[FirebaseConstants
                                                      .location],
                                                ),
                                              ],
                                            ),
                                          ),
                                          const Spacer(),
                                          IconButton(
                                              onPressed: () async {
                                                if (data[
                                                        FirebaseConstants.id] ==
                                                    AppSharedPrefrence().id) {
                                                  CommonMethods()
                                                      .appShowDialoge(
                                                          message: AppStrings
                                                              .deletePost,
                                                          context: context,
                                                          yesOnPressed:
                                                              () async {
                                                            Navigator.pop(
                                                                context);
                                                            homeScreenProvider.deletPost(
                                                                id: data[
                                                                    FirebaseConstants
                                                                        .postId],
                                                                context:
                                                                    context);
                                                          });
                                                } else {
                                                  AppCommonSnackBar()
                                                      .appCommonSnackbar(
                                                          context,
                                                          AppStrings
                                                              .youCanNotDeleteAnothersPost);
                                                }
                                              },
                                              icon: const Icon(Icons.delete))
                                        ]),
                                        Container(
                                          color: AppColors.transparent,
                                          width: width,
                                          height: height * 0.3,
                                          child: GestureDetector(
                                            onDoubleTap: () {
                                              //TODO.. like
                                            },
                                            child: PageView.builder(
                                              scrollDirection: Axis.horizontal,
                                              itemCount: data[FirebaseConstants
                                                      .postImages]
                                                  .length,
                                              itemBuilder: (context, i) {
                                                return AppCommonCachedNetworkImage(
                                                  post: true,
                                                  imageUrl: data[
                                                      FirebaseConstants
                                                          .postImages][i],
                                                  errorIconSize: 10,
                                                  imageSize: 10,
                                                  isGroup: false,
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            Consumer<HomeScreenProvider>(
                                              builder: (context,
                                                      homeScreenConsumer,
                                                      child) =>
                                                  IconButton(
                                                      padding: EdgeInsets.zero,
                                                      onPressed: () {
                                                        AppCommonSnackBar()
                                                            .appCommonSnackbar(
                                                                context,
                                                                AppStrings
                                                                    .underProcess);
                                                        // homeScreenProvider
                                                        //     .postLiked(index);
                                                      },
                                                      icon: const Icon(
                                                        Icons.thumb_up,
                                                        color: AppColors.black,
                                                      )),
                                            ),
                                            IconButton(
                                                padding: EdgeInsets.zero,
                                                onPressed: () {
                                                  AppCommonSnackBar()
                                                      .appCommonSnackbar(
                                                          context,
                                                          AppStrings
                                                              .underProcess);
                                                },
                                                icon: const Icon(
                                                    Icons.comment_rounded)),
                                            IconButton(
                                                padding: EdgeInsets.zero,
                                                onPressed: () {
                                                  AppCommonSnackBar()
                                                      .appCommonSnackbar(
                                                          context,
                                                          AppStrings
                                                              .underProcess);
                                                },
                                                icon: Image.asset(
                                                  AppImages.messageIcon,
                                                  height: 25,
                                                  color: AppColors.black,
                                                ))
                                          ],
                                        ),
                                        Container(
                                          padding:
                                              const EdgeInsets.only(left: 10),
                                          alignment: Alignment.centerLeft,
                                          child: Text.rich(
                                            TextSpan(children: [
                                              TextSpan(
                                                text: data[
                                                    FirebaseConstants.userName],
                                                style:
                                                    CommonTextStyles.boldText,
                                              ),
                                              const TextSpan(text: ' '),
                                              TextSpan(
                                                text: data[
                                                    FirebaseConstants.message],
                                              )
                                            ]),
                                          ),
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            AppCommonSnackBar()
                                                .appCommonSnackbar(context,
                                                    AppStrings.underProcess);
                                          },
                                          child: Container(
                                              color: AppColors.transparent,
                                              padding: const EdgeInsets.only(
                                                  left: 10),
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                AppStrings.viewAllComment,
                                                style: CommonTextStyles
                                                    .white18w500
                                                    .copyWith(
                                                        color:
                                                            AppColors.grey800,
                                                        fontSize: 12),
                                              )),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10),
                                          // alignment: Alignment.centerLeft,
                                          child: Align(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              data[FirebaseConstants
                                                          .sendTime] ==
                                                      null
                                                  ? ''
                                                  : '${AppConstants.timeAgo(data[FirebaseConstants.sendTime])}',
                                              style: CommonTextStyles
                                                  .white18w500
                                                  .copyWith(
                                                      color: AppColors.grey800,
                                                      fontSize: 12),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  );
                                },
                              ),
                            );
                          }
                        }
                      })
                ],
              ),
        bottomSheet: Consumer<HomeScreenProvider>(
          builder: (context, homeScreenConsumer, child) =>
              !(homeScreenConsumer.openMenu)
                  ? const SizedBox.shrink()
                  : Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: width * 0.3,
                      ),
                      padding: const EdgeInsets.all(10),
                      alignment: Alignment.center,
                      height: height * 0.1,
                      decoration: const BoxDecoration(
                          color: AppColors.primaryColor,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20))),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.pushNamed(
                                  context, GenratedRoutes.userProfileScreen,
                                  arguments: {
                                    FirebaseConstants.id: _localData.id,
                                    FirebaseConstants.descriptions:
                                        '${_localData.description}',
                                    FirebaseConstants.userName:
                                        '${_localData.username}',
                                    FirebaseConstants.phoneNumber:
                                        '${_localData.phoneNo}',
                                    FirebaseConstants.photoURL:
                                        _localData.userProfile ?? '',
                                    FirebaseConstants.currentUser: true,
                                  });
                            },
                            child: AppCommonCachedNetworkImage(
                              errorIconSize: width * 0.04,
                              imageSize: width * 0.05,
                              imageUrl: _localData.userProfile,
                              isGroup: false,
                              post: false,
                            ),
                          ),
                          // SizedBox(
                          //   width: 10,
                          // ),
                          IconButton(
                              padding: EdgeInsets.zero,
                              onPressed: () => Navigator.pushNamed(
                                  context, GenratedRoutes.addPostScreen),
                              icon: Icon(
                                Icons.add_box_outlined,
                                color: AppColors.white,
                                size: width * 0.1,
                              ))
                        ],
                      ),
                    ),
        ),
      ),
    );
  }
}
