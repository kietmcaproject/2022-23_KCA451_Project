import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/widgets/app_common_cached_network_image.dart';

import 'package:flutter/material.dart';

class UserNameWithImageWidget extends StatelessWidget {
  final String userName;
  final String? userProfile;
  final void Function()? onTap;
  final Widget? iconWidget;
  final bool storySeen;

  const UserNameWithImageWidget(
      {Key? key,
      required this.userName,
      required this.userProfile,
      this.storySeen = false,
      this.onTap,
      this.iconWidget})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;

    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 75,
        child: Column(
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  margin:
                      const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                  height: 66,
                  width: 66,
                  decoration: BoxDecoration(
                      gradient: !storySeen
                          ? AppColors.disableGradient
                          : AppColors.enableGradient,
                      shape: BoxShape.circle),
                ),
                AppCommonCachedNetworkImage(
                  imageUrl: userProfile,
                  errorIconSize: width * 0.09,
                  imageSize: width * 0.075,
                  isGroup: false,
                  post: false,
                ),
                iconWidget != null
                    ? Positioned(
                        right: 5,
                        bottom: 10,
                        child: CircleAvatar(
                            radius: 12, child: Center(child: iconWidget)),
                      )
                    : const SizedBox.shrink()
              ],
            ),
            SizedBox(
                child: Text(
              userName,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ))
          ],
        ),
      ),
    );
  }
}
