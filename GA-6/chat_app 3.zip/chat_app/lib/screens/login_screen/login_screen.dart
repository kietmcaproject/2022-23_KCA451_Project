// ignore_for_file: use_build_context_synchronously

import 'package:chat_app/app_shared_prefreneces/local_data.dart';

import 'package:chat_app/providers/login_screen_provider.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/validator/email_validator.dart';
import 'package:chat_app/utlis/validator/password_validator.dart';
import 'package:chat_app/utlis/widgets/app_common_background.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:chat_app/utlis/widgets/app_elevated_button.dart';
import 'package:chat_app/utlis/widgets/app_text_button.dart';
import 'package:chat_app/utlis/widgets/common_text_form_field.dart';
import 'package:chat_app/utlis/widgets/gradient_text.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../utlis/app_helper/app_images.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    LoginScreenProvider loginScreenProvider = Provider.of(context);
    return AppCommonBackground(
      widget: ListView(
        physics: const NeverScrollableScrollPhysics(),
        children: [
          GradientText(AppStrings.login,
              style: CommonTextStyles.primaryTextStyle),
          SizedBox(
            height: height * 0.05,
          ),
          Form(
            key: loginScreenProvider.loginFormKey,
            onChanged: loginScreenProvider.onTextFieldChanged,
            child: Column(
              children: [
                CommonTextFormField(
                  labelText: AppStrings.email,
                  textInputAction: TextInputAction.next,
                  keyboardType: TextInputType.emailAddress,
                  validator: EmailValidator().validateEmail,
                  controller: loginScreenProvider.emailController,
                  prefixIcon: Icon(
                    Icons.email_sharp,
                    size: 25,
                    color: AppColors.grey800,
                  ),
                ),
                SizedBox(
                  height: height * 0.03,
                ),
                Consumer<LoginScreenProvider>(
                  builder: (context, loginConsumer, child) =>
                      CommonTextFormField(
                    labelText: AppStrings.password,
                    textInputAction: TextInputAction.done,
                    keyboardType: TextInputType.visiblePassword,
                    onPressed: loginConsumer.obscureText,
                    obscure: loginConsumer.obscure,
                    controller: loginScreenProvider.passwordController,
                    validator: PasswordValidator().validatePassword,
                    suffixIcon: true,
                    prefixIcon: Icon(
                      Icons.lock,
                      size: 25,
                      color: AppColors.grey800,
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: ApptextButton(
                    text: '${AppStrings.forgot} ${AppStrings.password}?',
                    onPressed: () async {
                      Navigator.pushReplacementNamed(
                          context, GenratedRoutes.forgotPasswordScreen);
                    },
                  ),
                ),
                SizedBox(
                  height: height * 0.06,
                ),
                Consumer<LoginScreenProvider>(
                  builder: (context, loginConsumer, child) => AppElevatedButton(
                    text: AppStrings.submit,
                    enableButton: loginConsumer.enableButton,
                    loader: loginConsumer.buttonLoader,
                    onPressed: loginConsumer.enableButton
                        ? () async {
                            if (loginScreenProvider.loginFormKey.currentState!
                                .validate()) {
                              await loginConsumer.userLogin(
                                context,
                              );
                              AppSharedPrefrence().getCurrentUser();
                            }
                          }
                        : null,
                  ),
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(AppStrings.dontHaveAccount),
              ApptextButton(
                text: '${AppStrings.signUp} ${AppStrings.here}',
                onPressed: () {
                  Navigator.pushNamed(context, GenratedRoutes.signin);
                },
              )
            ],
          ),
          // social media icons
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () async {
                  await loginScreenProvider.googleLogin(context);
                },
                child: Container(
                  width: width * 0.08,
                  decoration: const BoxDecoration(
                    color: AppColors.white,
                    shape: BoxShape.circle,
                  ),
                  child: Image.asset(AppImages.googleIcon),
                ),
              ),
              SizedBox(
                width: width * 0.08,
              ),
              GestureDetector(
                onTap: () async {
                  AppCommonSnackBar()
                      .appCommonSnackbar(context, AppStrings.underProcess);
                },
                child: Container(
                  width: width * 0.1,
                  height: height * 0.1,
                  decoration: const BoxDecoration(
                    color: AppColors.white,
                    shape: BoxShape.circle,
                  ),
                  child: Image.asset(AppImages.facebookIcon),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
