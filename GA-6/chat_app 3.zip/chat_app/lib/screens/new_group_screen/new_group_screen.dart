import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/providers/new_group_screen_provider.dart';
import 'package:chat_app/screens/home_screen/user_name_with_image_widget.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_common_appbar.dart';
import 'package:chat_app/utlis/widgets/user_info_tile.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../utlis/widgets/app_netowrk_error.dart';

class NewGroupScreen extends StatelessWidget {
  final bool screen;
  final List<String>? listOfGroupMembers;
  final String? chatRoomId;
  const NewGroupScreen({
    Key? key,
    required this.screen,
    required this.listOfGroupMembers,
    required this.chatRoomId,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Consumer2<NewGroupScreenProvider, AppCommonProvider>(
      builder: (context, newGroupScreenConsumer, appCommonConsumer, child) {
        appCommonConsumer.allUsers?.removeWhere(
          (element) => element?[FirebaseConstants.isGroup] == true,
        );

        return AppCommonAppBar(
          text: screen ? AppStrings.newGroup : AppStrings.addMemberScreen,
          body: appCommonConsumer.connectivity
              ? const AppNetworkErrorWidget()
              : newGroupScreenConsumer.loader
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: AppColors.primaryColor,
                      ),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 10,
                        ),
                        newGroupScreenConsumer.groupChatWithUser.isEmpty
                            ? const SizedBox.shrink()
                            : SizedBox(
                                height: height * 0.15,
                                child: ListView.builder(
                                  scrollDirection: Axis.horizontal,
                                  shrinkWrap: true,
                                  itemCount: newGroupScreenConsumer
                                      .groupChatWithUser.length,
                                  itemBuilder: (context, index) {
                                    Map<dynamic, dynamic>? selectedUSerData =
                                        appCommonConsumer.allUsers!.firstWhere(
                                            (userMap) =>
                                                userMap![
                                                    FirebaseConstants.id] ==
                                                newGroupScreenConsumer
                                                    .groupChatWithUser[index]);
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 5),
                                      child: UserNameWithImageWidget(
                                        iconWidget: InkWell(
                                            onTap: () {
                                              newGroupScreenConsumer
                                                  .removeChatUser(
                                                      newGroupScreenConsumer
                                                              .groupChatWithUser[
                                                          index]);
                                            },
                                            child: const Icon(Icons.close)),
                                        userName: selectedUSerData![
                                            FirebaseConstants.userName],
                                        userProfile: selectedUSerData[
                                            FirebaseConstants.photoURL],
                                      ),
                                    );
                                  },
                                ),
                              ),
                        Expanded(
                          child: ListView.builder(
                              itemCount: appCommonConsumer.allUsers!.length,
                              itemBuilder: (context, index) {
                                // print("11 $listOfGroupMembers");
                                return UserInfoTile(
                                  selected: newGroupScreenConsumer.selected(
                                      appCommonConsumer.allUsers![index]
                                          ?[FirebaseConstants.id]),
                                  onTap: screen
                                      ? () {
                                          newGroupScreenConsumer.chatWithUser(
                                              appCommonConsumer.allUsers![
                                                  index]![FirebaseConstants.id],
                                              context);
                                        }
                                      : newGroupScreenConsumer
                                              .isAllReadyInGroup(
                                                  groupMembers:
                                                      listOfGroupMembers ?? [],
                                                  id: appCommonConsumer
                                                          .allUsers![index]![
                                                      FirebaseConstants.id])
                                          ? null
                                          : () {
                                              newGroupScreenConsumer
                                                  .chatWithUser(
                                                      appCommonConsumer
                                                                  .allUsers![
                                                              index]![
                                                          FirebaseConstants.id],
                                                      context);
                                            },
                                  subTitle: screen
                                      ? (appCommonConsumer.allUsers![index]![
                                              FirebaseConstants.descriptions] ??
                                          '')
                                      : newGroupScreenConsumer
                                              .isAllReadyInGroup(
                                                  groupMembers:
                                                      listOfGroupMembers ?? [],
                                                  id: appCommonConsumer
                                                          .allUsers![index]![
                                                      FirebaseConstants.id])
                                          ? AppStrings.allReadyInGroup
                                          : appCommonConsumer.allUsers![index]![
                                                  FirebaseConstants
                                                      .descriptions] ??
                                              '',
                                  userImage: appCommonConsumer.allUsers![
                                      index]![FirebaseConstants.photoURL],
                                  username: appCommonConsumer.allUsers![index]![
                                      FirebaseConstants.userName],
                                );
                              }),
                        ),
                      ],
                    ),
          floatingActionButton: (screen
                  ? newGroupScreenConsumer.groupChatWithUser.length < 2
                  : newGroupScreenConsumer.groupChatWithUser.isEmpty)
              ? null
              : FloatingActionButton(
                  backgroundColor: AppColors.primaryColor,
                  onPressed: () async {
                    if (screen) {
                      Navigator.pushReplacementNamed(
                          context, GenratedRoutes.addGroupDetailScreen,
                          arguments: newGroupScreenConsumer.groupChatWithUser);
                    } else {
                      listOfGroupMembers
                          ?.addAll(newGroupScreenConsumer.groupChatWithUser);
                      await newGroupScreenConsumer.addMemberToGroup(
                          lastAdded: newGroupScreenConsumer.groupChatWithUser,
                          context: context,
                          data: {
                            FirebaseConstants.userPath: listOfGroupMembers
                          },
                          chatRoomId: chatRoomId!);
                    }
                  },
                  child: Icon(
                    screen ? Icons.forward : Icons.done,
                  ),
                ),
        );
      },
    );
  }
}
