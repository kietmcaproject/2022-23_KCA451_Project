// ignore_for_file: use_build_context_synchronously

import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/providers/signup_screen_provider.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/validator/email_validator.dart';
import 'package:chat_app/utlis/validator/password_validator.dart';
import 'package:chat_app/utlis/validator/phoneno_validator.dart';
import 'package:chat_app/utlis/validator/user_name_validator.dart';
import 'package:chat_app/utlis/widgets/app_common_background.dart';
import 'package:chat_app/utlis/widgets/app_elevated_button.dart';
import 'package:chat_app/utlis/widgets/app_text_button.dart';
import 'package:chat_app/utlis/widgets/common_text_form_field.dart';
import 'package:chat_app/utlis/widgets/gradient_text.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SignupScreen extends StatelessWidget {
  SignupScreen({Key? key}) : super(key: key);
  final FirebaseAuth _initialize = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;

    SignUpScreenProvider signupScreenProvider =
        Provider.of(context, listen: false);

    return AppCommonBackground(
      containerHeight: 0.1,
      widget: ListView(
        padding: EdgeInsets.zero,
        physics: const ClampingScrollPhysics(),
        children: [
          GradientText(AppStrings.signUp,
              style: CommonTextStyles.primaryTextStyle),
          SizedBox(
            height: height * 0.02,
          ),
          Consumer<SignUpScreenProvider>(
            builder: (context, signupScreenConsumer, child) =>
                (signupScreenConsumer.imageFile == null)
                    ? GestureDetector(
                        onTap: () async {
                          signupScreenConsumer.imageLoader = true;

                          signupScreenConsumer.getImage(
                              await Provider.of<AppCommonProvider>(context,
                                      listen: false)
                                  .imagePicking(context));
                          signupScreenConsumer.imageLoader = false;
                        },
                        child: Stack(
                          alignment: Alignment.bottomCenter,
                          children: [
                            Container(
                              alignment: Alignment.center,
                              padding: EdgeInsets.all(height * 0.04),
                              margin: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                  gradient: AppColors.enableGradient,
                                  shape: BoxShape.circle),
                              child: const Icon(
                                Icons.camera_enhance,
                                size: 40,
                                color: AppColors.white,
                              ),
                            ),
                            Positioned(
                                bottom: height * 0.025,
                                child: Text(
                                  AppStrings.upload,
                                  textAlign: TextAlign.center,
                                  style: CommonTextStyles.white18w500.copyWith(
                                      color: AppColors.black, fontSize: 14),
                                ))
                          ],
                        ))
                    : signupScreenConsumer.imageLoader
                        ? Container(
                            alignment: Alignment.center,
                            margin: const EdgeInsets.all(10),
                            padding: EdgeInsets.all(height * 0.043),
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: AppColors.grey100,
                                border: Border.all(
                                    color: AppColors.grey800, width: 1.5)),
                            child: const CircularProgressIndicator(
                              color: AppColors.primaryColor,
                            ),
                          )
                        : Container(
                            margin: const EdgeInsets.all(10),
                            padding: EdgeInsets.all(height * 0.07),
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: AppColors.grey800, width: 1.5),
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    image: FileImage(
                                      (signupScreenConsumer.imageFile!),
                                    ),
                                    fit: BoxFit.fill)),
                          ),
          ),
          Form(
            key: signupScreenProvider.signUpFormKey,
            onChanged: () {
              signupScreenProvider.onTextFieldChanged();
            },
            child: Column(
              children: [
                CommonTextFormField(
                  labelText: AppStrings.userName,
                  textInputAction: TextInputAction.next,
                  keyboardType: TextInputType.name,
                  validator: UserNameValidator().validateUserName,
                  controller: signupScreenProvider.nameController,
                  prefixIcon: Icon(
                    Icons.person,
                    size: 25,
                    color: AppColors.grey800,
                  ),
                ),
                SizedBox(
                  height: height * 0.03,
                ),
                CommonTextFormField(
                  labelText: AppStrings.enterGroupdescription,
                  textInputAction: TextInputAction.newline,

                  keyboardType: TextInputType.multiline,

                  // validator: UserNameValidator().validateUserName,
                  controller: signupScreenProvider.descriptionController,
                  prefixIcon: Icon(
                    Icons.text_fields,
                    size: 25,
                    color: AppColors.grey800,
                  ),
                ),
                SizedBox(
                  height: height * 0.03,
                ),
                CommonTextFormField(
                  labelText: AppStrings.email,
                  textInputAction: TextInputAction.next,
                  keyboardType: TextInputType.emailAddress,
                  validator: EmailValidator().validateEmail,
                  controller: signupScreenProvider.emailController,
                  prefixIcon: Icon(
                    Icons.email_sharp,
                    size: 25,
                    color: AppColors.grey800,
                  ),
                ),
                SizedBox(
                  height: height * 0.03,
                ),
                CommonTextFormField(
                  labelText: AppStrings.phoneNo,
                  textInputAction: TextInputAction.next,
                  keyboardType: TextInputType.phone,
                  maxLength: 10,
                  validator: PhoneNoValidator().phoneNoValidation,
                  controller: signupScreenProvider.phoneNoController,
                  prefixIcon: Icon(
                    Icons.phone,
                    size: 25,
                    color: AppColors.grey800,
                  ),
                ),
                SizedBox(
                  height: height * 0.03,
                ),
                Consumer<SignUpScreenProvider>(
                  builder: (context, signUpConsumer, child) =>
                      CommonTextFormField(
                    labelText: AppStrings.password,
                    textInputAction: TextInputAction.done,
                    keyboardType: TextInputType.visiblePassword,
                    onPressed: signUpConsumer.obscureText,
                    obscure: signUpConsumer.obscure,
                    controller: signUpConsumer.passwordController,
                    validator: PasswordValidator().validatePassword,
                    suffixIcon: true,
                    prefixIcon: Icon(
                      Icons.lock,
                      size: 25,
                      color: AppColors.grey800,
                    ),
                  ),
                ),
                SizedBox(
                  height: height * 0.05,
                ),
                Consumer<SignUpScreenProvider>(
                  builder: (context, signUpConsumer, child) =>
                      AppElevatedButton(
                    loader: signUpConsumer.buttonLoader,
                    text: AppStrings.submit,
                    enableButton: signUpConsumer.enableButton,
                    onPressed: signUpConsumer.enableButton
                        ? () async {
                            if (signupScreenProvider.signUpFormKey.currentState!
                                .validate()) {
                              await signUpConsumer.addUser(
                                _initialize,
                                context,
                              );
                            }
                          }
                        : null,
                  ),
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(AppStrings.doYouHaveAnAccount),
              ApptextButton(
                text: '${AppStrings.login} ${AppStrings.here}',
                onPressed: () {
                  Navigator.pushNamed(context, GenratedRoutes.login);
                },
              )
            ],
          ),
          SizedBox(
            height: height * 0.3,
          ),
        ],
      ),
    );
  }
}
