import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/providers/search_screen_provider.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_netowrk_error.dart';
import 'package:chat_app/utlis/widgets/user_info_tile.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../utlis/widgets/common_text_form_field.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SearchedScreenProvider searchScreenProvider =
        Provider.of(context, listen: false);

    return Scaffold(body: Consumer<AppCommonProvider>(
        builder: (context, appCommonConsumer, child) {
      searchScreenProvider.getAllData(appCommonConsumer.allUsers);
      return appCommonConsumer.connectivity
          ? const AppNetworkErrorWidget()
          : Padding(
              padding: EdgeInsets.symmetric(
                  vertical: MediaQuery.of(context).padding.top + 10,
                  horizontal: 10),
              child: Column(
                children: [
                  CommonTextFormField(
                    labelText: '',
                    onChanged: (String text) {
                      searchScreenProvider.onChanegd();
                      // appCommonConsumer.searchingData(text);
                    },
                    prefixIcon: Icon(
                      Icons.search,
                      color: AppColors.grey800,
                    ),
                    controller: searchScreenProvider.searchController,
                    textInputAction: TextInputAction.done,
                  ),
                  Expanded(
                    child: Consumer<SearchedScreenProvider>(
                        builder: (context, searchScreenConsumer, child) {
                      return Column(
                        children: [
                          SizedBox(
                            height: searchScreenConsumer.searched ? 0 : 10,
                          ),
                          (!searchScreenConsumer.searched)
                              ? UserInfoTile(
                                  onTap: () => Navigator.pushReplacementNamed(
                                      context, GenratedRoutes.newGroupScreen,
                                      arguments: {
                                        AppStrings.searchedScreen: true,
                                        AppStrings.groupMembers: [null],
                                        FirebaseConstants.chatRoomId: null
                                      }),
                                  isGroup: true,
                                  subTitle: '',
                                  userImage: '',
                                  username: AppStrings.grouChat,
                                )
                              : const SizedBox.shrink(),
                          searchScreenConsumer.searched
                              ? (searchScreenConsumer.searchedData.isEmpty)
                                  ? const Text(AppStrings.noUSerFound)
                                  : Expanded(
                                      child: ListView.builder(
                                          itemCount: searchScreenConsumer
                                              .searchedData.length,
                                          itemBuilder: (context, ind) {
                                            return UserInfoTile(
                                              subTitle: searchScreenConsumer
                                                          .searchedData[ind][
                                                      FirebaseConstants
                                                          .descriptions] ??
                                                  '',
                                              onTap: () {
                                                Navigator.pushReplacementNamed(
                                                    context,
                                                    GenratedRoutes
                                                        .chatDetailScreen,
                                                    arguments: {
                                                      AppStrings.searchedData:
                                                          searchScreenConsumer
                                                                  .searchedData[
                                                              ind],
                                                      AppStrings.searchedScreen:
                                                          true
                                                    });
                                              },
                                              username: searchScreenConsumer
                                                      .searchedData[ind]
                                                  [FirebaseConstants.userName],
                                              userImage: searchScreenConsumer
                                                      .searchedData[ind]
                                                  [FirebaseConstants.photoURL],
                                            );
                                          }),
                                    )
                              : Expanded(
                                  child: ListView.builder(
                                    padding: EdgeInsets.zero,
                                    itemCount:
                                        appCommonConsumer.allUsers!.length,
                                    itemBuilder: (context, index) {
                                      return UserInfoTile(
                                        onTap: () {
                                          Navigator.pushReplacementNamed(
                                              context,
                                              GenratedRoutes.chatDetailScreen,
                                              arguments: {
                                                AppStrings.searchedData:
                                                    appCommonConsumer
                                                        .allUsers?[index],
                                                AppStrings.searchedScreen: true
                                              });
                                        },
                                        subTitle:
                                            appCommonConsumer.allUsers?[index]
                                                    ?[FirebaseConstants
                                                        .descriptions] ??
                                                '',
                                        username:
                                            '${appCommonConsumer.allUsers?[index]?[FirebaseConstants.userName]}',
                                        userImage:
                                            appCommonConsumer.allUsers?[index]
                                                ?[FirebaseConstants.photoURL],
                                      );
                                    },
                                  ),
                                )
                        ],
                      );
                    }),
                  )
                ],
              ),
            );
    }));
  }
}
