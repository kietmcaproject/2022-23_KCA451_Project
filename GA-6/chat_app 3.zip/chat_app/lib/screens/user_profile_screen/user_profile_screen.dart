// ignore_for_file: use_build_context_synchronously, must_be_immutable

import 'dart:io';
import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/providers/user_profile_provider.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/common_methods.dart/common_methods.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_common_cached_network_image.dart';
import 'package:chat_app/utlis/widgets/app_common_snackbar.dart';
import 'package:chat_app/utlis/widgets/app_netowrk_error.dart';
import 'package:chat_app/utlis/widgets/common_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class UserProfileScreen extends StatelessWidget {
  final String description;
  final String id;
  final String phoneNo;
  final String username;
  String photoUrl;
  final bool user;

  UserProfileScreen(
      {Key? key,
      required this.description,
      required this.phoneNo,
      required this.username,
      required this.photoUrl,
      required this.user,
      required this.id})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    AppCommonProvider appCommonProvider = Provider.of(context, listen: true);

    return Consumer<UserProfileScreenProvider>(
        builder: (context, userProfileConsumer, child) {
      userProfileConsumer.onInt(
          description: description, username: username, phoneNo: phoneNo);
      return Scaffold(
          appBar: AppBar(
            centerTitle: true,
            title: Text(
              AppStrings.userInfo,
              style: CommonTextStyles.primaryTextStyle,
            ),
            backgroundColor: AppColors.primaryColor,
            leading: IconButton(
              icon: const Icon(
                Icons.arrow_back,
                color: AppColors.white,
              ),
              onPressed: () => Navigator.pop(context),
            ),
            actions: !user
                ? []
                : [
                    IconButton(
                        onPressed: () {
                          CommonMethods().appShowDialoge(
                              message: AppStrings.logout,
                              context: context,
                              yesOnPressed: () async {
                                Navigator.pop(context);
                                if (appCommonProvider.connectivity) {
                                  AppCommonSnackBar().appCommonSnackbar(
                                      context, AppStrings.networkError);
                                } else {
                                  bool logOut =
                                      await userProfileConsumer.logout();
                                  logOut
                                      ? Navigator.pushNamedAndRemoveUntil(
                                          context,
                                          GenratedRoutes.login,
                                          (route) => false)
                                      : AppCommonSnackBar().appCommonSnackbar(
                                          context, AppStrings.serverError);
                                }
                              });
                        },
                        icon: const Icon(
                          Icons.power_settings_new,
                          color: AppColors.red,
                        )),
                    userProfileConsumer.edit
                        ? IconButton(
                            onPressed: () async {
                              userProfileConsumer.imageFile == null
                                  ? null
                                  : userProfileConsumer.getPhotoUrl(
                                      await appCommonProvider.uploadImageFile(
                                          context,
                                          id,
                                          userProfileConsumer.imageFile!));
                              await userProfileConsumer.update(id, {
                                FirebaseConstants.userName:
                                    userProfileConsumer.nameController.text,
                                FirebaseConstants.descriptions:
                                    userProfileConsumer
                                        .descriptionController.text,
                                FirebaseConstants.id: id,
                                FirebaseConstants.phoneNumber:
                                    userProfileConsumer.phoneNoController.text,
                                FirebaseConstants.photoURL:
                                    userProfileConsumer.photoUrl ?? photoUrl,
                              });
                              userProfileConsumer.nonEditable();
                              await AppSharedPrefrence().getCurrentUser();
                            },
                            icon: const Icon(Icons.done))
                        : IconButton(
                            onPressed: userProfileConsumer.editable,
                            icon: const Icon(Icons.edit))
                  ],
          ),
          body: appCommonProvider.connectivity
              ? const AppNetworkErrorWidget()
              : userProfileConsumer.logoutLoader
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: AppColors.primaryColor,
                      ),
                    )
                  : ListView(padding: const EdgeInsets.all(10), children: [
                      SizedBox(
                        height: height * 0.05,
                      ),
                      Center(
                        child: Stack(
                          children: [
                            userProfileConsumer.imageFile == null
                                ? Center(
                                    child: AppCommonCachedNetworkImage(
                                        imageUrl: photoUrl,
                                        imageSize: width * 0.15,
                                        post: false,
                                        isGroup: true,
                                        errorIconSize: width * 0.15),
                                  )
                                : Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8),
                                    child: CircleAvatar(
                                      backgroundColor: AppColors.white,
                                      radius: width * 0.15,
                                      foregroundImage: FileImage(
                                          userProfileConsumer.imageFile!),
                                      child: userProfileConsumer.imageLoader
                                          ? const Center(
                                              child: CircularProgressIndicator(
                                                color: AppColors.primaryColor,
                                              ),
                                            )
                                          : const SizedBox.shrink(),
                                    ),
                                  ),
                            user
                                ? Positioned(
                                    right: userProfileConsumer.imageFile == null
                                        ? width * 0.33
                                        : width * 0.03,
                                    bottom: width * 0.02,
                                    child: GestureDetector(
                                      onTap: () async {
                                        if (userProfileConsumer.edit) {
                                          userProfileConsumer.imageLoading();
                                          File? image = await appCommonProvider
                                              .imagePicking(context);
                                          userProfileConsumer.getImage(image);

                                          userProfileConsumer.imageLoading();
                                        } else {
                                          AppCommonSnackBar().appCommonSnackbar(
                                              context, 'Not Editable');
                                        }
                                      },
                                      child: Icon(
                                        Icons.camera_enhance,
                                        color: userProfileConsumer.edit
                                            ? AppColors.primaryColor
                                            : AppColors.black,
                                      ),
                                    ),
                                  )
                                : const SizedBox.shrink()
                          ],
                        ),
                      ),
                      SizedBox(
                        height: height * 0.04,
                      ),
                      CommonTextFormField(
                          labelText: AppStrings.userName,
                          readOnly: userProfileConsumer.edit ? false : true,
                          controller: userProfileConsumer.nameController,
                          textInputAction: TextInputAction.next),
                      SizedBox(
                        height: height * 0.02,
                      ),
                      CommonTextFormField(
                          keyboardType: TextInputType.number,
                          labelText: AppStrings.phoneNo,
                          maxLength: 10,
                          readOnly: userProfileConsumer.edit ? false : true,
                          controller: userProfileConsumer.phoneNoController,
                          textInputAction: TextInputAction.next),
                      SizedBox(
                        height: height * 0.02,
                      ),
                      CommonTextFormField(
                          labelText: AppStrings.description,
                          readOnly: userProfileConsumer.edit ? false : true,
                          controller: userProfileConsumer.descriptionController,
                          textInputAction: TextInputAction.done),
                      SizedBox(
                        height: height * 0.02,
                      ),
                    ]));
    });
  }
}
