// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:io';
import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/model/user_post_model.dart';
import 'package:chat_app/providers/app_common_provider.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/routes/app_ongenrated_routes.dart';
import 'package:chat_app/utlis/widgets/app_elevated_button.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class VerificationScreen extends StatefulWidget {
  final String name;
  final String phoneNo;
  final String description;

  final File imageFile;

  const VerificationScreen({
    Key? key,
    required this.name,
    required this.phoneNo,
    required this.imageFile,
    required this.description,
  }) : super(key: key);

  @override
  State<VerificationScreen> createState() => _VerificationScreenState();
}

class _VerificationScreenState extends State<VerificationScreen> {
  final auth = FirebaseAuth.instance;
  User? _user;
  Timer? _timer;
  String? photoUrl;

  @override
  void initState() {
    super.initState();
    _user = auth.currentUser;
    _user!.sendEmailVerification();
    _timer = Timer.periodic(const Duration(seconds: 2), (timer) async {
      await _checkemailVerification();
      UserPostModel userPostData = UserPostModel(
          userId: _user!.uid,
          postImage: [photoUrl],
          location: AppStrings.newPost,
          time: FieldValue.serverTimestamp(),
          message: '#${AppStrings.newPost}');
      _user!.emailVerified
          ? Provider.of<AppCommonProvider>(context, listen: false)
              .addPost(userPostData)
          : null;
    });
  }

  @override
  void dispose() {
    _timer!.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Text(
                '${AppStrings.aLinkIsSendTo}${_user!.email}${AppStrings.forVerification}',
                textAlign: TextAlign.center,
                style: CommonTextStyles.boldText,
              ),
            ),
            SizedBox(
              height: height * 0.02,
            ),
            Center(
              child: AppElevatedButton(
                text: AppStrings.resend,
                buttonWidth: width * 0.25,
                enableButton: true,
                onPressed: () {
                  Navigator.pushReplacementNamed(
                      context, GenratedRoutes.verificationScreen);
                },
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<void> _checkemailVerification() async {
    final AppSharedPrefrence localData = AppSharedPrefrence();
    _user = auth.currentUser;
    await _user!.reload();
    if (_user!.emailVerified) {
      _timer!.cancel();

      photoUrl = await Provider.of<AppCommonProvider>(context, listen: false)
          .uploadImageFile(context, _user!.uid, widget.imageFile);
      await AppSharedPrefrence()
          .saveLocalData(key: FirebaseConstants.photoURL, value: photoUrl!);
      await localData.saveLocalData(
          key: FirebaseConstants.id, value: _user!.uid);
      await localData.saveLocalData(
          key: FirebaseConstants.descriptions, value: widget.description);
      await localData.saveLocalData(
          key: FirebaseConstants.email, value: _user!.email!);
      await localData.saveLocalData(
          key: FirebaseConstants.userName, value: widget.name);
      await localData.saveLocalData(
          key: FirebaseConstants.phoneNumber, value: widget.phoneNo);
      await FirebaseFirestore.instance
          .collection(FirebaseConstants.userPath)
          .doc(_user!.uid)
          .set({
        FirebaseConstants.id: _user!.uid,
        FirebaseConstants.descriptions: widget.description,
        FirebaseConstants.userName: widget.name,
        FirebaseConstants.phoneNumber: widget.phoneNo,
        FirebaseConstants.photoURL: photoUrl
      });
      Navigator.pushReplacementNamed(context, GenratedRoutes.homseScreen);
    }
  }
}
