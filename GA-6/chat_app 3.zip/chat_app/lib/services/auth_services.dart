import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:chat_app/firebase_options.dart';
import 'package:chat_app/app_shared_prefreneces/local_data.dart';
import 'package:chat_app/model/user_model.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthServices {
// login
  FirebaseAuth auth = FirebaseAuth.instance;
  Future<UserDataModel> login(String email, String password) async {
    try {
      UserCredential userCredential = await auth
          .signInWithEmailAndPassword(email: email, password: password)
          .timeout(const Duration(seconds: 15));

      return UserDataModel(userCredentials: userCredential.user);
    } on FirebaseAuthException catch (e) {
      String? error;
      if (e.message ==
          'The password is invalid or the user does not have a password.') {
        error = 'Email or password invalid';
      } else if (e.message ==
          'Access to this account has been temporarily disabled due to many failed login attempts. You can immediately restore it by resetting your password or you can try again later.') {
        error = 'Too many attempts try after sometime or Forgot Password';
      } else if (e.message ==
          'There is no user record corresponding to this identifier. The user may have been deleted.') {
        error = 'User not found';
      }
      return UserDataModel(error: error);
    } on TimeoutException catch (e) {
      print(e.toString());
      return UserDataModel(error: 'Time out error');
    } on SocketException catch (e) {
      print(e.toString());
      return UserDataModel(error: 'Network error');
    } catch (e) {
      print(e.toString());
      return UserDataModel(error: 'Unknown error');
    }
  }
  // signup

  Future<UserDataModel?> signUp({
    required String email,
    required String password,
  }) async {
    try {
      UserCredential userCredential = await auth
          .createUserWithEmailAndPassword(email: email, password: password)
          .then((value) async {
        return value;
      }).timeout(const Duration(seconds: 15));

      return UserDataModel(userCredentials: userCredential.user);
    } on FirebaseAuthException catch (e) {
      return UserDataModel(error: e.message);
    }  
  }

  //
  // creating group
  Future<String?> createChatGroup(
      {required List<String> userToChat,
      required bool isGroup,
      String? sendBy,
      List<String>? groupAdmin,
      String? lastMessage,
      String? groupdescription,
      String? groupName,
      String? groupImageUrl}) async {
    List<QueryDocumentSnapshot<Map<String, dynamic>>> users =
        (await FirebaseFirestore.instance
                .collection(FirebaseConstants.chatRoompath)
                .get())
            .docs;
    for (int i = 0; i < users.length; i++) {
      Set<String> chatUserData = Set.of(
          (users[i].data()[FirebaseConstants.userPath] as List).cast<String>());
      Set<String> groupList = Set.of(userToChat);

      if ((chatUserData.difference(groupList).isEmpty) &&
          (chatUserData.length == groupList.length)) {
        return (users[i].id);
      }
    }
    DocumentReference<Map<String, dynamic>> doc = FirebaseFirestore.instance
        .collection(FirebaseConstants.chatRoompath)
        .doc();
    doc.set({
      FirebaseConstants.userPath: userToChat,
      FirebaseConstants.descriptions: groupdescription,
      FirebaseConstants.isGroup: isGroup,
      FirebaseConstants.userName: groupName,
      FirebaseConstants.photoURL: groupImageUrl,
      FirebaseConstants.groupAdmin: groupAdmin,
      FirebaseConstants.sendby: sendBy,
      FirebaseConstants.lastMessage: lastMessage?.trim(),
      FirebaseConstants.sendTime: FieldValue.serverTimestamp()
    });

    return doc.id;
  }

  // adding groupid to the user database
  Future<void> chatWith(List<String> chatWithUser, String groupId) async {
    try {
      for (int i = 0; i < chatWithUser.length; i++) {
        await FirebaseFirestore.instance
            .collection(FirebaseConstants.userPath)
            .doc(chatWithUser[i])
            .collection(FirebaseConstants.chatUserList)
            .doc(groupId)
            .set({
          FirebaseConstants.sendTime: FieldValue.serverTimestamp(),
          FirebaseConstants.groupId: groupId
        });
      } //
    } catch (e) {
      print('uha nhi hai\n $e');
    }
  }

  // getCurrentUSer
  Future<Map<String, dynamic>?> getUser(String uid) async {
    return (await FirebaseFirestore.instance
            .collection(FirebaseConstants.userPath)
            .doc(uid)
            .get())
        .data();
  }

// login with gogle
  Future<UserDataModel> handleGoogleSignIn() async {
    GoogleSignIn googleSignIn = GoogleSignIn(
        clientId: DefaultFirebaseOptions.currentPlatform.iosClientId);
    FirebaseAuth firebaseAuth = FirebaseAuth.instance;
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
    AppSharedPrefrence localData = AppSharedPrefrence();
    try {
      GoogleSignInAccount? googleUser = await googleSignIn.signIn();

      if (googleUser != null) {
        GoogleSignInAuthentication? googleAuth = await googleUser.authentication
            .timeout(const Duration(seconds: 15));
        final AuthCredential credential = GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken,
          idToken: googleAuth.idToken,
        );
        try {
          User? firebaseUser =
              (await firebaseAuth.signInWithCredential(credential)).user;

          if (firebaseUser != null) {
            final QuerySnapshot result = await firebaseFirestore
                .collection(FirebaseConstants.userPath)
                .where(FirebaseConstants.id, isEqualTo: firebaseUser.uid)
                .get()
                .timeout(const Duration(seconds: 15));
            final List<DocumentSnapshot> document = result.docs;
            if (document.isEmpty) {
              firebaseFirestore
                  .collection(FirebaseConstants.userPath)
                  .doc(firebaseUser.uid)
                  .set({
                FirebaseConstants.userName: firebaseUser.displayName,
                FirebaseConstants.photoURL: firebaseUser.photoURL,
                FirebaseConstants.email: firebaseUser.email,
                FirebaseConstants.phoneNumber: firebaseUser.phoneNumber ?? '',
                FirebaseConstants.id: firebaseUser.uid,
                FirebaseConstants.groupId: []
              });

              await localData.saveLocalData(
                  key: FirebaseConstants.id, value: firebaseUser.uid);
              await localData.saveLocalData(
                  key: FirebaseConstants.email, value: firebaseUser.email!);
              await localData.saveLocalData(
                  key: FirebaseConstants.userName,
                  value: firebaseUser.displayName!);
              await localData.saveLocalData(
                  key: FirebaseConstants.phoneNumber,
                  value: firebaseUser.phoneNumber ?? '');
              await localData.saveLocalData(
                  key: FirebaseConstants.photoURL,
                  value: firebaseUser.photoURL!);
            } else {
              Map<String, dynamic> currentUser =
                  document.map((e) => e.data() as Map<String, dynamic>).first;
              await localData.saveLocalData(
                  key: FirebaseConstants.id,
                  value: currentUser[FirebaseConstants.id]);
              await localData.saveLocalData(
                  key: FirebaseConstants.email,
                  value: currentUser[FirebaseConstants.email]);
              await localData.saveLocalData(
                  key: FirebaseConstants.userName,
                  value: currentUser[FirebaseConstants.userName]);
              await localData.saveLocalData(
                  key: FirebaseConstants.phoneNumber,
                  value: currentUser[FirebaseConstants.phoneNumber]);
              await localData.saveLocalData(
                  key: FirebaseConstants.photoURL,
                  value: currentUser[FirebaseConstants.photoURL]);
            }

            return UserDataModel(userCredentials: firebaseUser);
          } else {
            return UserDataModel(error: 'User not aded to firebase');
          }
        } on TimeoutException catch (e) {
          return UserDataModel(error: 'Time out error');
        }
      } else {
        return UserDataModel(error: 'Google login fail');
      }
    } catch (e) {
      return UserDataModel(error: e.toString());
    }
  }

// update collection using doc id
  Future<bool> updateDetailWithCollectionAndDocId({
    required String collectionId,
    required String chatRoomId,
    required Map<String, dynamic> data,
  }) async {
    return await FirebaseFirestore.instance
        .collection(collectionId)
        .doc(chatRoomId)
        .update(data)
        .then((value) {
      return true;
    }).catchError((error) {
      return false;
    });
  }

  // deleting data from firebase

  Future<bool> deleteDataByDocId(
      {required String collection,
      required String chatRoomId,
      String? otherUserId,
      String? otherCollection}) async {
    try {
      return (!(otherCollection == null ||
              otherCollection == '' ||
              otherCollection.isEmpty))
          ? await FirebaseFirestore.instance
              .collection(collection)
              .doc(otherUserId)
              .collection(otherCollection)
              .doc(chatRoomId)
              .delete()
              .then((value) => true)
              .catchError((e) {
              return false;
            })
          : await FirebaseFirestore.instance
              .collection(collection)
              .doc(chatRoomId)
              .delete()
              .then((value) => true)
              .catchError((error) {
              return false;
            });
    } catch (e) {
      return false;
    }
  }
  // add message

  void sendMessage({required String chatRoomId, required String message}) {
    DocumentReference<Map<String, dynamic>> addingChat = FirebaseFirestore
        .instance
        .collection(FirebaseConstants.chatRoompath)
        .doc(chatRoomId);

    addingChat.collection(FirebaseConstants.chats).add({
      FirebaseConstants.sendby: AppSharedPrefrence().id,
      FirebaseConstants.message: message,
      FirebaseConstants.sendTime: FieldValue.serverTimestamp()
    });
    addingChat.update({
      FirebaseConstants.sendby: AppSharedPrefrence().id,
      FirebaseConstants.lastMessage: message,
      FirebaseConstants.sendTime: FieldValue.serverTimestamp()
    });
  }
}
