// apconstants
import 'package:cloud_firestore/cloud_firestore.dart';

class AppConstants {
  static RegExp emailOrPhone = RegExp(r'\w+@\w+\.\w+|(^[1-9][0-9]{10,10}$)');
  static RegExp captialAlphabets = RegExp(r'[A-Z]');
  static RegExp lowerAlphabets = RegExp(r'[a-z]');
  static RegExp noDigits = RegExp(r'[0-9]');
  static RegExp mobileNo = RegExp(r'^[1-9][0-9]{9,13}$');
  static RegExp email =
      RegExp(r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$');
  static RegExp punctuation = RegExp(r'[!@#\$&*~-]');
  //
  static String intractWhen(Timestamp timestamp) {
    DateTime time = timestamp.toDate();
    Duration diff = DateTime.now().difference(time);

    if (diff.inDays <= 1) {
      return '${time.hour}:${time.minute}';
    } else if (diff.inDays > 1 && diff.inDays <= 2) {
      return 'yesterday';
    } else if (diff.inDays > 2) {
      return '${time.day}/${time.month}/${time.year}';
    } else {
      return 'just now';
    }
  }

  // id genrate
  String chatRoomId(String user1, String user2) {
    if (user1[0].toLowerCase().codeUnits[0] >
        user2[0].toLowerCase().codeUnits[0]) {
      return user1 + user2;
    } else {
      return user2 + user1;
    }
  }

  static String chatday(Timestamp timestamp) {
    DateTime sendTime = timestamp.toDate();

    DateTime.now();
    if (sendTime.month == DateTime.now().month &&
        sendTime.year == DateTime.now().year) {
      if (sendTime.day == DateTime.now().day) {
        return "today";
      } else if ((sendTime.day + 1) == DateTime.now().day) {
        return "yesterday";
      }
    }

    return '${sendTime.day}/${sendTime.month}/${sendTime.year}';
  }

  // ago

  static String? timeAgo(Timestamp? fetchedTimeStamp) {
    DateTime postDate = fetchedTimeStamp!.toDate();
    Duration different = DateTime.now().difference(postDate);

    if (different.inDays > 365) {
      return "${(different.inDays / 365).floor()} ${(different.inDays / 365).floor() == 1 ? "year" : "years"} ago";
    }
    if (different.inDays > 30) {
      return "${(different.inDays / 30).floor()} ${(different.inDays / 30).floor() == 1 ? "month" : "months"} ago";
    }
    if (different.inDays > 7) {
      return "${(different.inDays / 7).floor()} ${(different.inDays / 7).floor() == 1 ? "week" : "weeks"} ago";
    }
    if (different.inDays > 0) {
      return "${different.inDays} ${different.inDays == 1 ? "day" : "days"} ago";
    }
    if (different.inHours > 0) {
      return "${different.inHours} ${different.inHours == 1 ? "hour" : "hours"} ago";
    }
    if (different.inMinutes > 0) {
      return "${different.inMinutes} ${different.inMinutes == 1 ? "minute" : "minutes"} ago";
    }
    if (different.inMinutes == 0) return 'Just Now';

    return '';
  }

  static List<String> locationData = [
    'Noida',
    'Up-27,Shahjahanpur',
    'UP27 Wale',
    'Lucknow',
    'Apna Shaher Noida'
  ];
}
