import 'package:flutter/material.dart';

class AppColors {
  static const Color white = Color.fromARGB(255, 255, 255, 255);
  static const Color black = Color.fromARGB(255, 0, 0, 0);
  static Color grey100 = const Color.fromARGB(255 ~/ 4, 158, 158, 158);
  static Color grey800 = const Color.fromARGB(255, 160, 160, 160);
  static const Color transparent = Color.fromARGB(0, 0, 0, 0);
  static const Color primaryColor = Color.fromRGBO(173, 214, 251, 1);
  static const Color iconColor = Color.fromARGB(234, 242, 175, 94);
  static const Color red = Color.fromARGB(255, 244, 67, 54);
  static const Color green = Color.fromARGB(255, 76, 175, 80);

  static LinearGradient enableGradient = const LinearGradient(colors: [
    Color.fromRGBO(173, 214, 251, 1),
    Color.fromRGBO(173, 214, 228, 65)
  ]);
  static LinearGradient disableGradient =
      LinearGradient(colors: [grey800, grey800]);
}
