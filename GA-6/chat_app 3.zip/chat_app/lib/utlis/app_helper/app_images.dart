class AppImages {
  //images
  static const primaryImage = 'assets/images/primary_image.png';

  // icons
  static const googleIcon = 'assets/icons/googleIcon.png';
  static const facebookIcon = 'assets/icons/meta.png';
  static const messageIcon = 'assets/icons/message_icon.jpeg';
  static const userIcon = 'assets/icons/myAccounts.png';
  static const defaultUser = 'assets/icons/default_user.png';
  static const groupIcon = 'assets/icons/group_icon.png';
  static const errorIcon = 'assets/icons/error_icon.png';
}
