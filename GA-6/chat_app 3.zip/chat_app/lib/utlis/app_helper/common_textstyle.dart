import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CommonTextStyles {
  static TextStyle primaryTextStyle = GoogleFonts.roboto(
      textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 24));
  static TextStyle white10w500 = GoogleFonts.roboto(
      textStyle: const TextStyle(
          fontWeight: FontWeight.w500, fontSize: 10, color: AppColors.red));

  static const TextStyle boldText = TextStyle(fontWeight: FontWeight.w700);
  static TextStyle white18w500 = GoogleFonts.roboto(
      textStyle: const TextStyle(
          fontWeight: FontWeight.w500, fontSize: 18, color: AppColors.white));
}
