import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/widgets/app_text_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CommonMethods {
  bool _checkTextField(TextEditingController controler) {
    if (controler.text != '' && controler.text.isNotEmpty) {
      return true;
    } else {
      return false;
    }
  }

  bool enableButton(
    List<TextEditingController> controllers,
  ) {
    for (int i = 0; i < controllers.length; i++) {
      if (!_checkTextField(controllers[i])) {
        return false;
      }
    }
    return true;
  }

  // showdialoge box

  Future appShowDialoge(
      {required BuildContext context,
      required void Function()? yesOnPressed,
      required message}) {
    return showDialog(
        context: context,
        builder: (contex) => CupertinoAlertDialog(
              title: Text('${AppStrings.areYouSureTo}$message'),
              content: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ApptextButton(
                    fontSize: 16,
                    text: AppStrings.yes,
                    onPressed: yesOnPressed,
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.1,
                  ),
                  ApptextButton(
                    fontSize: 16,
                    text: AppStrings.no,
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ));
  }
}
