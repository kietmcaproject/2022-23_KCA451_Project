import 'package:chat_app/providers/add_post_screen_provider.dart';
import 'package:chat_app/providers/chat_detail_screen_provider.dart';
import 'package:chat_app/providers/chat_screen_provider.dart';
import 'package:chat_app/providers/forgot_password_screen_provider.dart';
import 'package:chat_app/providers/add_group_detail_provider.dart';
import 'package:chat_app/providers/group_detail_screen_provider.dart';
import 'package:chat_app/providers/home_screen_provider.dart';
import 'package:chat_app/providers/login_screen_provider.dart';
import 'package:chat_app/providers/new_group_screen_provider.dart';
import 'package:chat_app/providers/search_screen_provider.dart';
import 'package:chat_app/providers/signup_screen_provider.dart';
import 'package:chat_app/providers/user_profile_provider.dart';
import 'package:chat_app/screens/add_group_detail_screen/add_group_detail_screen.dart';
import 'package:chat_app/screens/add_post_screen/add_post_screen.dart';

import 'package:chat_app/screens/chat_details_screen/chat_details_screen.dart';
import 'package:chat_app/screens/chat_screen/chat_screen.dart';
import 'package:chat_app/screens/forgot_password_screen/forgot_password_screen.dart';
import 'package:chat_app/screens/group_detail_screen/group_detail_screen.dart';
// import 'package:chat_app/screens/group_detail_screen/group_detail_screen.dart';
import 'package:chat_app/screens/home_screen/home_screen.dart';
import 'package:chat_app/screens/login_screen/login_screen.dart';
import 'package:chat_app/screens/new_group_screen/new_group_screen.dart';
import 'package:chat_app/screens/registration_screen/signup_screen.dart';
import 'package:chat_app/screens/search_screen/search_screen.dart';
import 'package:chat_app/screens/user_profile_screen/user_profile_screen.dart';
import 'package:chat_app/screens/verification_screen/verification_screen.dart';
import 'package:chat_app/utlis/app_constants/app_firebase_keys.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:flutter/material.dart';

import 'package:provider/provider.dart';

class GenratedRoutes {
  static const String login = '/login';
  static const String signin = '/signin';
  static const String chatScreen = '/chatScreen';
  static const String searchScreen = '/searchScreen';
  static const String homseScreen = '/homeScreen';
  static const String chatDetailScreen = '/chatDetailScreen';
  static const String userProfileScreen = '/userProfileScreen';
  static const String verificationScreen = '/verificationScreen';
  static const String forgotPasswordScreen = '/forgotPasswordScreen';
  static const String addPostScreen = '/addStoryScreen';
  static const String newGroupScreen = '/newGroupScreen';
  static const String groupDetailScreen = '/groupDetailScreen';
  static const String addGroupDetailScreen = '/addGroupDetailScreen';
  // static const String groupDetailScreen = '/addGroupDetailScreen';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case login:
        return MaterialPageRoute(
            builder: ((context) => ChangeNotifierProvider(
                  create: (context) => LoginScreenProvider(),
                  child: const LoginScreen(),
                )));
      case signin:
        return MaterialPageRoute(
            builder: ((context) => ChangeNotifierProvider(
                  create: (context) => SignUpScreenProvider(),
                  child: SignupScreen(),
                )));
      case chatScreen:
        return MaterialPageRoute(
            builder: ((context) => ChangeNotifierProvider<ChatScreenProvider>(
                create: (BuildContext context) => ChatScreenProvider(),
                child: const ChatScreen())));
      case homseScreen:
        return MaterialPageRoute(
            builder: ((context) => ChangeNotifierProvider<HomeScreenProvider>(
                create: (BuildContext context) => HomeScreenProvider(),
                child: HomeScreen())));
      case searchScreen:
        return MaterialPageRoute(
            builder: ((context) =>
                ChangeNotifierProvider<SearchedScreenProvider>(
                    create: (BuildContext context) => SearchedScreenProvider(),
                    child: const SearchScreen())));
      case chatDetailScreen:
        Map<String, dynamic>? arg = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
            builder: ((context) =>
                ChangeNotifierProvider<ChatDetailScreenProvider>(
                  create: (BuildContext context) => ChatDetailScreenProvider(),
                  child: ChatDetailsScreen(
                    msgUser: arg[AppStrings.searchedData],
                    searchScreen: arg[AppStrings.searchedScreen],
                  ),
                )));

      case userProfileScreen:
        Map<String, dynamic> arg = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
            builder: ((context) =>
                ChangeNotifierProvider<UserProfileScreenProvider>(
                  create: (BuildContext context) => UserProfileScreenProvider(),
                  child: UserProfileScreen(
                    id: arg[FirebaseConstants.id] ?? '',
                    description: '${arg[FirebaseConstants.descriptions]}',
                    phoneNo: arg[FirebaseConstants.phoneNumber] ?? '',
                    username: arg[FirebaseConstants.userName] ?? '',
                    photoUrl: arg[FirebaseConstants.photoURL] ?? '',
                    user: arg[FirebaseConstants.currentUser] ?? '',
                  ),
                )));
      case verificationScreen:
        Map<String, dynamic> arg = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
            builder: ((context) => ChangeNotifierProvider<SignUpScreenProvider>(
                  create: (BuildContext context) => SignUpScreenProvider(),
                  child: VerificationScreen(
                    description: arg[FirebaseConstants.descriptions],
                    name: arg[FirebaseConstants.userName],
                    phoneNo: arg[FirebaseConstants.phoneNumber],
                    imageFile: arg[FirebaseConstants.imageFile],
                  ),
                )));
      case forgotPasswordScreen:
        return MaterialPageRoute(
            builder: ((context) =>
                ChangeNotifierProvider<ForgotPasswordScreenProvider>(
                    create: (BuildContext context) =>
                        ForgotPasswordScreenProvider(),
                    child: const ForgotPasswordScreen())));
      case newGroupScreen:
        Map<String, dynamic> args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
            builder: ((context) =>
                ChangeNotifierProvider<NewGroupScreenProvider>(
                  create: (BuildContext context) => NewGroupScreenProvider(),
                  child: NewGroupScreen(
                    chatRoomId: args[FirebaseConstants.chatRoomId],
                    screen: args[AppStrings.searchedScreen]!,
                    listOfGroupMembers:
                        (args[AppStrings.groupMembers] as List).cast<String>(),
                  ),
                )));

      case addPostScreen:
        return MaterialPageRoute(
            builder: ((context) =>
                ChangeNotifierProvider<AddPostScreenProvider>(
                    create: (BuildContext context) => AddPostScreenProvider(),
                    child: const AddPostScreen())));
      case groupDetailScreen:
        String args = settings.arguments as String;
        return MaterialPageRoute(
            builder: ((context) =>
                ChangeNotifierProvider<GroupDeatilScreenProvider>(
                  create: (BuildContext context) => GroupDeatilScreenProvider(),
                  child: GroupDetailScreen(
                    chatRoomId: args,
                    // groupChatWithUsersId: args,
                  ),
                )));
      case addGroupDetailScreen:
        List<String> args = settings.arguments as List<String>;
        return MaterialPageRoute(
            builder: ((context) =>
                ChangeNotifierProvider<AddGroupDetailScreenProvider>(
                    create: (BuildContext context) =>
                        AddGroupDetailScreenProvider(),
                    child: AddGroupDetailScreen(
                      chatWithUserList: args,
                    ))));
      default:
        return MaterialPageRoute(
            builder: ((context) => ChangeNotifierProvider(
                  create: (context) => LoginScreenProvider(),
                  child: const LoginScreen(),
                )));
    }
  }
}
