// email validation
import 'package:chat_app/utlis/app_constants/app_constants.dart';

class EmailValidator {
  String? validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return ' Email required';
    } else if (!AppConstants.email.hasMatch(value)) {
      return "Invalid email";
    } else {
      return null;
    }
  }
}
