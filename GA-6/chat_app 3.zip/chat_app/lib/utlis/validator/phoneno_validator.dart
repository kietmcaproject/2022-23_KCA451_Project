// phone no. validation
import 'package:chat_app/utlis/app_constants/app_constants.dart';

class PhoneNoValidator {
  String? phoneNoValidation(String? phoneNo) {
    if (phoneNo == null || phoneNo.isEmpty) {
      return 'Mobile no. required*';
    } else if (!AppConstants.mobileNo.hasMatch(phoneNo)) {
      return 'Mobile no. invalid*';
    }
    return null;
  }
}
