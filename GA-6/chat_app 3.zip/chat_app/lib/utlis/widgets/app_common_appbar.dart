import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:flutter/material.dart';

class AppCommonAppBar extends StatelessWidget {
  final String text;
  final Widget body;
  final List<Widget>? appBarAction;
  final double? toolbarHeight;
  final Widget? flexibleSpace;
  final Widget? floatingActionButton;
  final Widget? appBarLeadingIcon;
  final bool floatCenter;
  final Widget? bottomNavigationBar;
  final Widget? bottomSheet;
  const AppCommonAppBar({
    Key? key,
    required this.text,
    required this.body,
    this.appBarLeadingIcon,
    this.floatingActionButton,
    this.appBarAction,
    this.toolbarHeight,
    this.flexibleSpace,
    this.floatCenter = false,
    this.bottomNavigationBar,
    this.bottomSheet,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // bottomNavigationBar: bottomNavigationBar,
      bottomSheet: bottomSheet,
      floatingActionButtonLocation:
          floatCenter ? FloatingActionButtonLocation.centerDocked : null,
      appBar: AppBar(
        toolbarHeight: toolbarHeight,
        flexibleSpace: flexibleSpace,
        actions: appBarAction,
        centerTitle: true,
        leading: appBarLeadingIcon ??
            IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => Navigator.pop(context),
            ),
        title: Text(
          text,
          style: CommonTextStyles.primaryTextStyle,
        ),
        backgroundColor: AppColors.primaryColor,
      ),
      body: body,
      floatingActionButton: floatingActionButton,
    );
  }
}
