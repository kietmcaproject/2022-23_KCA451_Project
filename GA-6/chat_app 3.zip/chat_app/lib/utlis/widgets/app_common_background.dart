import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_images.dart';
import 'package:flutter/material.dart';

class AppCommonBackground extends StatelessWidget {
  final Widget widget;
  final double containerHeight;
  const AppCommonBackground(
      {Key? key, required this.widget, this.containerHeight = 0.25})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: ListView(
        shrinkWrap: true,
        padding: EdgeInsets.zero,
        physics: const ClampingScrollPhysics(),
        children: [
          GestureDetector(
            onTap: (() {
              FocusScope.of(context).requestFocus(FocusNode());
            }),
            child: SizedBox(
              height: height,
              width: width,
              child: Stack(children: [
                Container(
                  height: MediaQuery.of(context).size.height * 0.5,
                  decoration: const BoxDecoration(
                      color: AppColors.transparent,
                      image: DecorationImage(
                          image: AssetImage(
                            AppImages.primaryImage,
                          ),
                          fit: BoxFit.cover)),
                ),
                Positioned(
                  top: height * containerHeight,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 15, vertical: 20),
                    width: width,
                    height: height,
                    decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(width * 0.16))),
                    child: widget,
                  ),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
