import 'package:cached_network_image/cached_network_image.dart';
import 'package:chat_app/utlis/app_helper/app_images.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:flutter/material.dart';
import '../app_helper/app_colors.dart';

class AppCommonCachedNetworkImage extends StatelessWidget {
  final String? imageUrl;
  final double imageSize;
  final bool post;
  final bool isGroup;

  final double errorIconSize;
  const AppCommonCachedNetworkImage({
    Key? key,
    this.imageUrl,
    required this.imageSize,
    required this.post,
    required this.isGroup,
    required this.errorIconSize,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return (imageUrl == null || imageUrl == '')
        ? (post
            ? const Center(
                child: Text(AppStrings.noImage),
              )
            : CircleAvatar(
                radius: imageSize,
                backgroundColor: AppColors.white,
                backgroundImage: AssetImage(
                    isGroup ? AppImages.groupIcon : AppImages.userIcon)))
        : CachedNetworkImage(
            imageUrl: imageUrl!,
            imageBuilder: (context, image) => post
                ? Container(
                    decoration:
                        BoxDecoration(image: DecorationImage(image: image)),
                  )
                : CircleAvatar(
                    radius: imageSize,
                    foregroundImage: image,
                  ),
            placeholder: (context, error) => const Center(
                  child: CircularProgressIndicator(
                    color: AppColors.primaryColor,
                  ),
                ),
            errorWidget: (context, error, d) {
              return CircleAvatar(
                radius: errorIconSize,
                backgroundImage: const AssetImage(AppImages.errorIcon),
                backgroundColor: AppColors.primaryColor,
                child: Text(
                  AppStrings.serverError,
                  textAlign: TextAlign.center,
                  style: CommonTextStyles.white10w500,
                ),
              );
            });
  }
}
