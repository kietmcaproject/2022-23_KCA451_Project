import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:flutter/material.dart';

class AppElevatedButton extends StatelessWidget {
  final String text;
  final bool enableButton;
  final bool loader;
  final double buttonWidth;
  final void Function()? onPressed;
  const AppElevatedButton(
      {Key? key,
      required this.text,
      this.onPressed,
      this.enableButton = false,
      this.loader = false,
      this.buttonWidth = double.infinity})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 50,
        width: buttonWidth,
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
                color: AppColors.grey800,
                spreadRadius: 2,
                blurRadius: 5,
                offset: const Offset(0, 2))
          ],
          // color: AppColors.white,
          borderRadius: BorderRadius.circular(10),
          gradient: enableButton
              ? AppColors.enableGradient
              : AppColors.disableGradient,
        ),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            primary: AppColors.transparent,
            shadowColor: AppColors.transparent,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
          onPressed: loader ? null : onPressed,
          child: loader
              ? const CircularProgressIndicator(
                  color: AppColors.white,
                )
              : Text(
                  text,
                  style: CommonTextStyles.white18w500,
                ),
        ));
  }
}
