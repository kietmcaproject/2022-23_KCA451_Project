import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:flutter/material.dart';

class AppNetworkErrorWidget extends StatefulWidget {
  const AppNetworkErrorWidget({Key? key}) : super(key: key);

  @override
  State<AppNetworkErrorWidget> createState() => _AppNetworkErrorWidgetState();
}

class _AppNetworkErrorWidgetState extends State<AppNetworkErrorWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          Icons.error,
          color: AppColors.red,
          size: MediaQuery.of(context).size.width * 0.1,
        ),
        const SizedBox(
          height: 10,
        ),
        Center(
          child: Text(AppStrings.networkError,
              textAlign: TextAlign.center,
              style: CommonTextStyles.white18w500.copyWith(
                color: AppColors.grey800,
              )),
        )
      ],
    );
  }
}
