import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:flutter/material.dart';

class ApptextButton extends StatelessWidget {
  final String text;
  final Color? textColor;
  final double? fontSize;

  final void Function()? onPressed;
  const ApptextButton(
      {Key? key,
      required this.text,
      this.onPressed,
      this.textColor,
      this.fontSize})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextButton(
        onPressed: onPressed,
        child: Text(
          text,
          style: CommonTextStyles.white18w500.copyWith(
              fontSize: fontSize ?? 12,
              color: textColor ?? AppColors.primaryColor),
        ));
  }
}
