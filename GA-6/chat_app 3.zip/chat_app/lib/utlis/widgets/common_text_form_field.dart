// ignore_for_file: must_be_immutable

import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:flutter/material.dart';

class CommonTextFormField extends StatelessWidget {
  final TextEditingController controller;
  final String labelText;
  final void Function(String)? onChanged;
  final String? Function(String?)? validator;
  final TextInputAction textInputAction;
  final bool readOnly;
  final Widget? prefixIcon;
  final Widget? suffixIconWidget;
  final void Function()? onTap;
  final bool suffixIcon;
  final bool obscure;

  final int? maxLength;
  final void Function()? onPressed;
  final TextInputType? keyboardType;
  CommonTextFormField(
      {Key? key,
      required this.controller,
      this.keyboardType,
      this.validator,
      this.prefixIcon,
      this.suffixIcon = false,
      this.obscure = true,
      this.onPressed,
      this.maxLength,
      required this.textInputAction,
      this.suffixIconWidget,
      this.onTap,
      this.readOnly = false,
      this.onChanged,
      required this.labelText})
      : super(key: key);

  OutlineInputBorder borderEnable = OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: AppColors.primaryColor));
  OutlineInputBorder borderDisable = OutlineInputBorder(
      borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none);
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      readOnly: readOnly,
      onTap: onTap,
      textInputAction: textInputAction,
      onChanged: onChanged,
      maxLength: maxLength,
      minLines: 1,
      maxLines: obscure ? 1 : 8,
      scrollPadding: const EdgeInsets.only(bottom: 20),
      validator: validator,
      cursorColor: AppColors.grey800,
      controller: controller,
      keyboardType: keyboardType,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      obscureText: suffixIcon ? obscure : false,
      decoration: InputDecoration(
          labelText: labelText,
          labelStyle: CommonTextStyles.white18w500
              .copyWith(color: AppColors.primaryColor),
          counterText: '',
          filled: true,
          fillColor: AppColors.grey100,
          errorBorder: borderEnable,
          border: borderDisable,
          enabledBorder: borderDisable,
          focusedBorder: borderEnable,
          focusedErrorBorder: borderEnable,
          prefixIcon: prefixIcon,
          suffixIcon: suffixIcon
              ? suffixIconWidget ??
                  IconButton(
                      onPressed: onPressed,
                      icon: Icon(
                        obscure ? Icons.visibility_off : Icons.visibility,
                        color: AppColors.grey800,
                      ))
              : null),
    );
  }
}
