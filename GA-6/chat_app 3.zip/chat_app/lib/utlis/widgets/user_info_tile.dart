import 'package:chat_app/utlis/app_helper/app_colors.dart';
import 'package:chat_app/utlis/app_helper/app_strings.dart';
import 'package:chat_app/utlis/app_helper/common_textstyle.dart';
import 'package:chat_app/utlis/widgets/app_common_cached_network_image.dart';
import 'package:flutter/material.dart';

class UserInfoTile extends StatelessWidget {
  final bool newMessage;
  final bool isGroup;
  final String userImage;
  final String username;
  final String subTitle;
  final String? sendBy;
  final void Function()? onLongPress;
  final bool selected;

  final String? time;
  final bool? admin;

  final void Function()? onTap;
  const UserInfoTile({
    Key? key,
    this.newMessage = false,
    required this.userImage,
    required this.username,
    required this.subTitle,
    this.onTap,
    this.time,
    this.isGroup = false,
    this.selected = false,
    this.sendBy,
    this.admin = false,
    this.onLongPress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double height = MediaQuery.of(context).size.height;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
      decoration: BoxDecoration(
          color: AppColors.transparent,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
                color: newMessage
                    ? AppColors.primaryColor
                    : AppColors.grey100.withOpacity(0.3),
                blurRadius: 10,
                blurStyle: BlurStyle.outer,
                spreadRadius: 3)
          ]),
      child: ListTile(
        onLongPress: onLongPress,
        onTap: onTap,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        contentPadding: EdgeInsets.zero,
        style: ListTileStyle.list,
        horizontalTitleGap: 5,
        leading: Stack(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width * 0.2,
              child: AppCommonCachedNetworkImage(
                errorIconSize: MediaQuery.of(context).size.width * 0.17,
                imageSize: MediaQuery.of(context).size.width * 0.15,
                imageUrl: userImage,
                isGroup: isGroup,
                post: false,
              ),
            ),
            selected
                ? CircleAvatar(
                    radius: height * 0.02,
                    backgroundColor: AppColors.primaryColor,
                    child: const Icon(
                      Icons.done,
                      color: AppColors.white,
                    ),
                  )
                : const SizedBox.shrink()
          ],
        ),
        title: Text(
          username,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Text(
          sendBy == null ? subTitle : '$sendBy: $subTitle',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: Padding(
          padding: const EdgeInsets.only(right: 5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              (admin == null || admin == false)
                  ? Text(time == null ? '' : time.toString())
                  : Container(
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                          border: Border.all(color: AppColors.green),
                          borderRadius: BorderRadius.circular(5)),
                      child: Text(
                        AppStrings.admin,
                        style: CommonTextStyles.white10w500
                            .copyWith(color: AppColors.green),
                      ),
                    ),
              const SizedBox(
                height: 10,
              ),
              CircleAvatar(
                radius: height * 0.01,
                backgroundColor: AppColors.transparent,
                child: Text(
                  '',
                  style: CommonTextStyles.white18w500.copyWith(fontSize: 14),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
