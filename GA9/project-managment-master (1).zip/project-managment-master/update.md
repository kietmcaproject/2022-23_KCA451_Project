Majorly We Have To Work On Some Points : <br/>
Create Group Of Peoples and assigned them task<br/>
create user fuctionality Of project leader with his Team <br/>
Assign a project ForceFully..<br/>
